import { useState, useEffect } from 'react';
import { categories, type Product } from '../data/products';
import HeroSection from './HeroSection';
import ProductCard from './ProductCard';
import { Helmet } from 'react-helmet-async';
import { supabase } from '../lib/supabase';

interface HomePageProps {
  onShopNow: () => void;
  onSelectCategory: (catId: string) => void;
  onViewProduct: (product: Product) => void;
}

export default function HomePage({ onShopNow, onSelectCategory, onViewProduct }: HomePageProps) {
  const [bestSellers, setBestSellers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchFeaturedProducts();
  }, []);

  const fetchFeaturedProducts = async () => {
    const { data } = await supabase
      .from('products')
      .select('*')
      .limit(4);
    
    if (data) {
      const mapped = data.map(p => ({
        ...p,
        image: p.image_url,
        originalPrice: p.original_price,
        customizable: p.is_customizable,
        features: ['Premium Quality', 'Handcrafted', 'Fast Shipping'],
        customizationOptions: p.customization_options || []
      }));
      setBestSellers(mapped);
    }
    setLoading(false);
  };

  return (
    <div>
      <Helmet>
        <title>MystiGifts | Personalised Gifts for Every Occasion</title>
        <meta name="description" content="Shop premium personalized gifts, custom 3D acrylic lamps, photo frames, and customized presents for birthdays, anniversaries, and Valentine's Day." />
      </Helmet>
      <HeroSection onShopNow={onShopNow} />

      {/* Categories Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 py-16">
        <div className="text-center mb-10">
          <span className="text-sm font-bold text-[#BFA364] uppercase tracking-wider">Shop by Category</span>
          <h2 className="font-headline text-3xl sm:text-4xl text-slate-900 mt-2">Browse Our Collection</h2>
          <p className="text-slate-500 mt-2">Choose a category to see custom designs and personalization options</p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {categories.map((cat) => {
            const img = cat.image;
            return (
              <button
                key={cat.id}
                onClick={() => onSelectCategory(cat.id)}
                className="group bg-white rounded-2xl border border-slate-200/70 overflow-hidden text-center hover:shadow-xl hover:shadow-slate-100 hover:-translate-y-1 transition-all duration-300"
              >
                <div className="h-36 overflow-hidden bg-slate-100">
                    <img src={img} alt={cat.name} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300" />
                </div>
                <div className="p-3">
                  <h3 className="font-bold text-slate-900 text-sm group-hover:text-[#BFA364] transition-colors">{cat.name}</h3>
                  <p className="text-xs text-slate-400 mt-1 line-clamp-2">{cat.description}</p>
                </div>
              </button>
            );
          })}
        </div>
      </section>

      {/* Bestsellers */}
      <section className="bg-gradient-to-b from-slate-50 to-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="flex items-center justify-between mb-8">
            <div>
              <span className="text-sm font-bold text-[#BFA364] uppercase tracking-wider">Trending</span>
              <h2 className="font-headline text-3xl text-slate-900 mt-1">Featured Products</h2>
            </div>
            <button
              onClick={onShopNow}
              className="text-slate-900 font-bold hover:text-[#BFA364] hidden sm:inline-flex items-center gap-1"
            >
              View All →
            </button>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6">
            {loading ? (
              [...Array(4)].map((_, i) => (
                <div key={i} className="aspect-square bg-slate-100 animate-pulse rounded-2xl" />
              ))
            ) : (
              bestSellers.map((product) => (
                <ProductCard key={product.id} product={product} onViewProduct={onViewProduct} />
              ))
            )}
          </div>
        </div>
      </section>

      {/* How it works */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 py-16">
        <div className="text-center mb-10">
          <span className="text-sm font-bold text-[#BFA364] uppercase tracking-wider">How It Works</span>
          <h2 className="font-section text-3xl text-slate-900 mt-2">Order in 3 Easy Steps</h2>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {[
            {
              step: '01',
              title: 'Curate Your Gift',
              desc: 'Select from our premium collection and provide your personalisation details.',
            },
            {
              step: '02',
              title: 'Secure Checkout',
              desc: 'Complete your purchase using our encrypted payment gateway for peace of mind.',
            },
            {
              step: '03',
              title: 'Handcrafted Delivery',
              desc: 'Our artisans prepare your order for shipping within 3-5 business days.',
            },
          ].map((item) => (
            <div key={item.step} className="group p-8 rounded-3xl bg-white border border-slate-100 hover:shadow-2xl hover:shadow-slate-200 transition-all duration-500">
              <div className="text-4xl font-headline text-slate-300 group-hover:text-[#BFA364] transition-all duration-500 mb-4 tracking-widest">
                {item.step}
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-3 tracking-tight">{item.title}</h3>
              <p className="text-slate-500 text-sm leading-relaxed">{item.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Modern CTA Banner */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 py-12">
        <div className="relative overflow-hidden rounded-[2.5rem] bg-slate-900 text-white min-h-[400px] flex items-center">
          <div className="absolute inset-0 opacity-40">
            <img
              src="/images/product-acrylic-lamp-valentine.jpg"
              alt="Background"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-slate-900 via-slate-900/60 to-transparent" />
          </div>
          <div className="relative z-10 p-8 sm:p-16 max-w-2xl">
            <span className="text-xs font-bold uppercase tracking-[0.4em] text-[#BFA364]">Exclusive Collection</span>
            <h2 className="font-headline mt-4 text-4xl sm:text-5xl tracking-tight leading-tight">Artisanal Gifts for Life's Milestones</h2>
            <p className="mt-6 text-lg text-slate-300 leading-relaxed">
              Experience the perfect blend of modern design and personal touch. Each piece is crafted to tell your unique story.
            </p>
            <button
              onClick={onShopNow}
              className="mt-10 rounded-none bg-[#BFA364] px-10 py-4 font-bold text-white transition-all hover:bg-[#A68A50] hover:shadow-xl hover:shadow-[#BFA364]/20"
            >
              Shop Now
            </button>
          </div>
        </div>
      </section>

      {/* Professional Features */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 py-20">
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {[
            { title: 'Priority Shipping', desc: 'Complimentary delivery on all orders exceeding ₹500.' },
            { title: 'Quality Guarantee', desc: 'Meticulously crafted using industrial-grade materials.' },
            { title: 'Personalized Art', desc: 'Each design is reviewed by our in-house creative team.' },
            { title: 'Secure Payment', desc: 'Enterprise-grade encryption for every transaction.' },
          ].map((item, i) => (
            <div key={i} className="border-l-2 border-slate-100 pl-6 py-2">
              <h3 className="font-bold text-slate-900 mb-2">{item.title}</h3>
              <p className="text-slate-500 text-sm leading-relaxed">{item.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Instagram CTA */}
      <section className="bg-slate-50 py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 text-center">
          <span className="text-sm font-bold text-[#BFA364] uppercase tracking-wider">Follow Us</span>
          <h2 className="font-section text-3xl text-slate-900 mt-2">@mystigifts_official</h2>
          <p className="text-gray-500 mt-2 mb-6">
            Follow us on Instagram for new launches, offers & happy customer stories
          </p>
          <a
            href="https://www.instagram.com/mystigifts_official"
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-2 px-8 py-3 bg-slate-900 text-white rounded-full font-bold hover:bg-slate-800 transition-all"
          >
            Follow on Instagram
          </a>
        </div>
      </section>
    </div>
  );
}
