import { Product } from '../data/products';

interface ProductCardProps {
  product: Product;
  onViewProduct: (product: Product) => void;
}

export default function ProductCard({ product, onViewProduct }: ProductCardProps) {
  const discount = Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100);

  return (
    <div
      onClick={() => onViewProduct(product)}
      className="group bg-white rounded-2xl border border-slate-200/60 overflow-hidden hover:shadow-xl hover:shadow-slate-100 transition-all duration-300 cursor-pointer hover:-translate-y-1"
    >
      {/* Product Image Area */}
      <div className="relative bg-gradient-to-br from-slate-50 to-slate-100/50 flex items-center justify-center h-64 overflow-hidden">
        <img
          src={product.image}
          alt={product.name}
          className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/20 via-transparent to-transparent" />

        {/* Badge */}
        {product.badge && (
          <span className="absolute top-3 left-3 bg-slate-900 text-white text-xs font-bold px-3 py-1 rounded-full">
            {product.badge}
          </span>
        )}



        {/* Quick view overlay */}
        <div className="absolute inset-0 bg-black/0 group-hover:bg-slate-900/5 transition-all flex items-center justify-center">
          <span className="opacity-0 group-hover:opacity-100 transition-all translate-y-4 group-hover:translate-y-0 bg-white/95 backdrop-blur-sm text-slate-900 font-bold px-6 py-3 border border-slate-200 text-[10px] tracking-[0.2em] uppercase shadow-2xl">
            View Selection
          </span>
        </div>
      </div>

      {/* Product Info */}
      <div className="p-5 text-center">
        <h3 className="font-bold text-slate-800 group-hover:text-[#C5A059] transition-colors line-clamp-1 mb-2 text-xs tracking-wide">
          {product.name}
        </h3>

        {/* Price */}
        <div className="flex flex-col items-center">
          <span className="text-sm font-bold text-slate-900">₹{product.price}</span>
          <span className="text-[10px] text-slate-400 line-through">₹{product.originalPrice}</span>
        </div>
      </div>
    </div>
  );
}
