import { useState, useSyncExternalStore, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';
import AuthModal from './AuthModal';
import {
  getCart,
  subscribeToCart,
  removeFromCart,
  updateQuantity,
  getCartTotal,
  clearCart,
  loadCartFromSupabase,
  type CustomerDetails,
} from '../store/cartStore';

interface CartPageProps {
  onClose: () => void;
  onContinueShopping: () => void;
}

export default function CartPage({ onClose, onContinueShopping }: CartPageProps) {
  const cart = useSyncExternalStore(subscribeToCart, getCart);
  const total = useSyncExternalStore(subscribeToCart, getCartTotal);
  const { user } = useAuth();
  const [authModalOpen, setAuthModalOpen] = useState(false);

  useEffect(() => {
    if (user) {
      loadCartFromSupabase();
    }
  }, [user]);

  const [step, setStep] = useState<'cart' | 'details' | 'payment' | 'success'>('cart');
  const [paymentMethod, setPaymentMethod] = useState<'cashfree' | 'cod'>('cashfree');
  const [processing, setProcessing] = useState(false);
  const [orderNumber, setOrderNumber] = useState('');

  const [customer, setCustomer] = useState<CustomerDetails>({
    fullName: '',
    phone: '',
    email: '',
    address: '',
    city: '',
    pincode: '',
    state: '',
  });

  const shipping = total >= 500 ? 0 : 49;
  const grandTotal = total + shipping;

  const handlePlaceOrder = async () => {
    if (!user) {
      setAuthModalOpen(true);
      return;
    }
    setProcessing(true);
    
    try {
      // 0. Verify Stock
      const { data: stockCheck, error: stockError } = await supabase
        .from('products')
        .select('id, name, stock_quantity')
        .in('id', cart.map(item => item.product.id));

      if (stockError) throw stockError;

      for (const item of cart) {
        const productStock = stockCheck.find(p => p.id === item.product.id);
        if (!productStock || productStock.stock_quantity < item.quantity) {
          throw new Error(`Insufficient stock for ${item.product.name}. Only ${productStock?.stock_quantity || 0} left.`);
        }
      }

      // 1. Create Order in Supabase
      const { data: orderData, error: orderError } = await supabase
        .from('orders')
        .insert({
          user_id: user.id,
          total_amount: grandTotal,
          status: 'pending',
          shipping_details: customer
        })
        .select()
        .single();
        
      if (orderError) throw orderError;
      
      const orderId = orderData.id;
      setOrderNumber(orderId.slice(0, 8).toUpperCase());

      // 2. Create Order Items & Update Stock
      const orderItems = cart.map(item => ({
        order_id: orderId,
        product_id: item.product.id,
        quantity: item.quantity,
        price_at_time: item.product.price,
        customization: item.customization
      }));

      const { error: itemsError } = await supabase
        .from('order_items')
        .insert(orderItems);
        
      if (itemsError) throw itemsError;

      // 3. Decrement Stock
      for (const item of cart) {
        await supabase.rpc('decrement_stock', { 
          product_id: item.product.id, 
          qty: item.quantity 
        });
      }

      // 4. Clear Cart & Show Success
      setStep('success');
      clearCart();
    } catch (err: any) {
      console.error(err);
      alert(err.message || 'Failed to place order. Please try again.');
    } finally {
      setProcessing(false);
    }
  };

  const isDetailsValid = customer.fullName && customer.phone && customer.address && customer.city && customer.pincode && customer.state;

  // Empty cart
  if (cart.length === 0 && step !== 'success') {
    return (
      <div className="fixed inset-0 z-50 bg-white overflow-y-auto">
        <div className="max-w-2xl mx-auto px-4 py-20 text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-3 uppercase tracking-widest">Your cart is empty</h2>
          <p className="text-gray-500 mb-8 font-section">Add some bespoke gifts to get started!</p>
          <button
            onClick={onContinueShopping}
            className="px-10 py-4 bg-slate-900 text-white rounded-none font-bold text-xs uppercase tracking-[0.2em] hover:bg-slate-800 transition-all shadow-lg"
          >
            Start Shopping
          </button>
        </div>
      </div>
    );
  }

  // Success page
  if (step === 'success') {
    return (
      <div className="fixed inset-0 z-50 bg-white overflow-y-auto">
        <div className="max-w-2xl mx-auto px-4 py-20 text-center">
          <div className="w-20 h-20 border-2 border-green-500 rounded-full flex items-center justify-center mx-auto mb-6">
            <svg className="w-10 h-10 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
            </svg>
          </div>
          <h2 className="text-3xl font-headline text-gray-900 mb-3 uppercase tracking-wider">Order Placed</h2>
          <p className="text-gray-500 mb-2">Order Number: <span className="font-bold text-[#BFA364]">{orderNumber}</span></p>
          <p className="text-gray-500 mb-8">
            Thank you for ordering from MystiGifts! We'll contact you on WhatsApp shortly to confirm your order and collect your personalisation details.
          </p>
          <div className="bg-slate-50 border border-slate-200 rounded-2xl p-6 mb-8 text-left max-w-md mx-auto">
            <h4 className="font-bold text-gray-900 mb-3">What's Next?</h4>
            <div className="space-y-3 text-sm text-gray-600">
              <div className="flex items-start gap-3">
                <p>Our team will reach you on your provided contact number.</p>
              </div>
              <div className="flex items-start gap-3">
                <p>We will collect your customisation requirements directly.</p>
              </div>
              <div className="flex items-start gap-3">
                <p>Your order will be handcrafted and shipped within 3-5 business days.</p>
              </div>
            </div>
          </div>
          <div className="flex flex-col gap-3 max-w-md mx-auto">
            <a
              href={`https://wa.me/919400262143?text=${encodeURIComponent(
                `Hello MystiGifts! I just placed Order #${orderNumber}. I'm sending my personalization details and photos now.`
              )}`}
              target="_blank"
              rel="noreferrer"
              className="w-full py-4 bg-green-500 text-white rounded-none font-bold text-xs uppercase tracking-[0.2em] hover:bg-green-600 transition-all shadow-xl flex items-center justify-center gap-2"
            >
              <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/>
              </svg>
              Send Details to WhatsApp
            </a>
            <button
              onClick={onContinueShopping}
              className="w-full py-4 border-2 border-slate-900 text-slate-900 rounded-none font-bold text-xs uppercase tracking-[0.2em] hover:bg-slate-900 hover:text-white transition-all"
            >
              Continue Shopping
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-50 bg-gray-50 overflow-y-auto">
      {/* Header */}
      <div className="bg-white border-b sticky top-0 z-10">
        <div className="max-w-4xl mx-auto px-4 py-4 flex items-center justify-between">
          <button onClick={onClose} className="flex items-center gap-2 text-gray-600 hover:text-gray-900">
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M15 19l-7-7 7-7" />
            </svg>
            Back
          </button>
          <h1 className="text-sm font-bold uppercase tracking-[0.2em] text-gray-900">
            {step === 'cart' && 'Your Selection'}
            {step === 'details' && 'Delivery Information'}
            {step === 'payment' && 'Payment Selection'}
          </h1>
          <div className="w-16" />
        </div>

        {/* Progress bar */}
        <div className="max-w-4xl mx-auto px-4 pb-4">
          <div className="flex items-center gap-2">
            {['Cart', 'Details', 'Payment'].map((label, i) => {
              const stepMap = ['cart', 'details', 'payment'];
              const currentIdx = stepMap.indexOf(step);
              return (
                <div key={label} className="flex items-center gap-2 flex-1">
                  <div
                    className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold ${
                      i <= currentIdx ? 'bg-slate-900 text-white' : 'bg-slate-200 text-slate-500'
                    }`}
                  >
                    {i + 1}
                  </div>
                  <span className={`text-sm font-bold hidden sm:inline ${i <= currentIdx ? 'text-slate-900' : 'text-slate-400'}`}>
                    {label}
                  </span>
                  {i < 2 && <div className={`flex-1 h-0.5 ${i < currentIdx ? 'bg-slate-900' : 'bg-slate-200'}`} />}
                </div>
              );
            })}
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 py-6">
        <div className="grid lg:grid-cols-3 gap-6">
          {/* Main content */}
          <div className="lg:col-span-2 space-y-4">
            {step === 'cart' && (
              <>
                {cart.map((item) => (
                  <div key={item.product.id} className="bg-white rounded-2xl p-4 sm:p-6 shadow-sm">
                    <div className="flex gap-4">
                      <div className="w-20 h-20 bg-slate-50 border border-slate-200/60 rounded-xl flex items-center justify-center flex-shrink-0 overflow-hidden">
                        <img src={item.product.image} alt={item.product.name} className="h-full w-full object-cover" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <h3 className="font-bold text-slate-900 truncate">{item.product.name}</h3>
                        <p className="text-sm text-slate-500">{item.product.category}</p>

                        {/* Customization details */}
                        {item.customization.names && (
                          <p className="text-[10px] text-[#BFA364] font-bold uppercase tracking-widest mt-1">Names: {item.customization.names}</p>
                        )}
                        {item.customization.specialDate && (
                          <p className="text-[10px] text-[#BFA364] font-bold uppercase tracking-widest mt-1">Date: {new Date(item.customization.specialDate).toLocaleDateString()}</p>
                        )}
                        {item.customization.message && (
                          <p className="text-[10px] text-slate-400 font-medium italic mt-1 line-clamp-1">"{item.customization.message}"</p>
                        )}
                        {item.customization.photoPreview && (
                          <p className="text-[10px] text-[#BFA364] font-bold uppercase tracking-widest mt-1">Asset provided</p>
                        )}

                        <div className="flex items-center justify-between mt-3">
                          <div className="flex items-center border rounded-lg overflow-hidden">
                            <button
                              onClick={() => updateQuantity(item.product.id, item.quantity - 1)}
                              className="px-2.5 py-1 hover:bg-gray-100 text-sm font-bold"
                            >
                              −
                            </button>
                            <span className="px-3 py-1 text-sm font-semibold">{item.quantity}</span>
                            <button
                              onClick={() => updateQuantity(item.product.id, item.quantity + 1)}
                              className="px-2.5 py-1 hover:bg-gray-100 text-sm font-bold"
                            >
                              +
                            </button>
                          </div>
                          <span className="font-bold text-gray-900">₹{item.product.price * item.quantity}</span>
                        </div>
                      </div>
                      <button
                        onClick={() => removeFromCart(item.product.id)}
                        className="text-gray-400 hover:text-red-500 p-1 self-start"
                      >
                        <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                          <path strokeLinecap="round" strokeLinejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                        </svg>
                      </button>
                    </div>
                  </div>
                ))}
              </>
            )}

            {step === 'details' && (
              <div className="bg-white rounded-2xl p-6 shadow-sm space-y-4">
                <h3 className="font-bold text-gray-900 text-sm uppercase tracking-widest border-b pb-2">Delivery Information</h3>
                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Full Name *</label>
                    <input
                      type="text"
                      value={customer.fullName}
                      onChange={(e) => setCustomer({ ...customer, fullName: e.target.value })}
                      placeholder="Enter your full name"
                      className="w-full px-4 py-2.5 border rounded-xl focus:ring-2 focus:ring-[#BFA364] outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Phone Number *</label>
                    <input
                      type="tel"
                      value={customer.phone}
                      onChange={(e) => setCustomer({ ...customer, phone: e.target.value })}
                      placeholder="+91 XXXXX XXXXX"
                      className="w-full px-4 py-2.5 border rounded-xl focus:ring-2 focus:ring-[#BFA364] outline-none"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Email Address</label>
                  <input
                    type="email"
                    value={customer.email}
                    onChange={(e) => setCustomer({ ...customer, email: e.target.value })}
                    placeholder="your@email.com"
                    className="w-full px-4 py-2.5 border rounded-xl focus:ring-2 focus:ring-amber-500 outline-none"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Delivery Address *</label>
                  <textarea
                    value={customer.address}
                    onChange={(e) => setCustomer({ ...customer, address: e.target.value })}
                    placeholder="House No, Street, Landmark"
                    rows={2}
                    className="w-full px-4 py-2.5 border rounded-xl focus:ring-2 focus:ring-amber-500 outline-none resize-none"
                  />
                </div>
                <div className="grid sm:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">City *</label>
                    <input
                      type="text"
                      value={customer.city}
                      onChange={(e) => setCustomer({ ...customer, city: e.target.value })}
                      placeholder="City"
                      className="w-full px-4 py-2.5 border rounded-xl focus:ring-2 focus:ring-[#BFA364] outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">State *</label>
                    <input
                      type="text"
                      value={customer.state}
                      onChange={(e) => setCustomer({ ...customer, state: e.target.value })}
                      placeholder="State"
                      className="w-full px-4 py-2.5 border rounded-xl focus:ring-2 focus:ring-[#BFA364] outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Pincode *</label>
                    <input
                      type="text"
                      value={customer.pincode}
                      onChange={(e) => setCustomer({ ...customer, pincode: e.target.value })}
                      placeholder="XXXXXX"
                      className="w-full px-4 py-2.5 border rounded-xl focus:ring-2 focus:ring-[#BFA364] outline-none"
                    />
                  </div>
                </div>
              </div>
            )}

            {step === 'payment' && (
              <div className="bg-white rounded-2xl p-6 shadow-sm space-y-4">
                <h3 className="font-bold text-gray-900 text-sm uppercase tracking-widest border-b pb-2">Select Payment Method</h3>

                {/* Cashfree */}
                <button
                  onClick={() => setPaymentMethod('cashfree')}
                  className={`w-full p-4 rounded-xl border-2 text-left transition-all ${
                    paymentMethod === 'cashfree'
                      ? 'border-slate-900 bg-slate-50'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                      paymentMethod === 'cashfree' ? 'border-slate-900' : 'border-gray-300'
                    }`}>
                      {paymentMethod === 'cashfree' && <div className="w-3 h-3 rounded-full bg-slate-900" />}
                    </div>
                    <div className="flex-1">
                      <h4 className="font-bold text-slate-900">Pay Online (Cashfree)</h4>
                      <p className="text-sm text-slate-500">UPI, Credit/Debit Card, Net Banking, Wallets</p>
                    </div>
                    <div className="flex gap-1 text-slate-300 text-[10px] font-bold">
                      <span>UPI</span>
                      <span>CARD</span>
                      <span>NET</span>
                    </div>
                  </div>
                  {paymentMethod === 'cashfree' && (
                    <div className="mt-3 ml-8 p-3 bg-white rounded-lg border text-sm text-slate-600">
                      <p className="flex items-center gap-2">Secure payments powered by Cashfree</p>
                      <p className="flex items-center gap-2">Supports GPay, PhonePe, Paytm & more</p>
                      <p className="flex items-center gap-2">Credit/Debit Cards accepted</p>
                    </div>
                  )}
                </button>

                {/* COD */}
                <button
                  onClick={() => setPaymentMethod('cod')}
                  className={`w-full p-4 rounded-xl border-2 text-left transition-all ${
                    paymentMethod === 'cod'
                      ? 'border-slate-900 bg-slate-50'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                      paymentMethod === 'cod' ? 'border-slate-900' : 'border-gray-300'
                    }`}>
                      {paymentMethod === 'cod' && <div className="w-3 h-3 rounded-full bg-slate-900" />}
                    </div>
                    <div className="flex-1">
                      <h4 className="font-bold text-slate-900">Cash on Delivery</h4>
                      <p className="text-sm text-slate-500">Pay when you receive your order</p>
                    </div>
                    <span className="text-[10px] font-bold text-slate-400">COD</span>
                  </div>
                </button>

                {/* Secure payment note */}
                <div className="flex items-center gap-2 p-3 bg-green-50 rounded-xl text-sm text-green-700">
                  <div className="w-2 h-2 rounded-full bg-green-500" />
                  <p>All transactions are secure and encrypted. Your payment details are safe with us.</p>
                </div>
              </div>
            )}
          </div>

          {/* Order Summary Sidebar */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-2xl p-6 shadow-sm sticky top-36">
              <h3 className="font-bold text-gray-900 text-sm uppercase tracking-widest mb-4 border-b pb-2">Order Summary</h3>

              <div className="space-y-3 mb-4">
                {cart.map((item) => (
                  <div key={item.product.id} className="flex justify-between text-sm">
                    <span className="text-gray-600">
                      {item.product.name} × {item.quantity}
                    </span>
                    <span className="font-medium">₹{item.product.price * item.quantity}</span>
                  </div>
                ))}
              </div>

              <div className="border-t pt-3 space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Subtotal</span>
                  <span>₹{total}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Shipping</span>
                  <span className={shipping === 0 ? 'text-green-600 font-medium' : ''}>
                    {shipping === 0 ? 'FREE' : `₹${shipping}`}
                  </span>
                </div>
                <div className="flex justify-between text-lg font-bold border-t pt-2">
                  <span>Total</span>
                  <span className="text-slate-900">₹{grandTotal}</span>
                </div>
              </div>

              {/* Action button */}
              <div className="mt-6">
                {step === 'cart' && (
                  <button
                    onClick={() => setStep('details')}
                    className="w-full py-3.5 bg-slate-900 text-white rounded-xl font-bold hover:bg-slate-800 transition-all"
                  >
                    Proceed to Checkout →
                  </button>
                )}
                {step === 'details' && (
                  <div className="space-y-3">
                    <button
                      onClick={() => setStep('payment')}
                      disabled={!isDetailsValid}
                      className="w-full py-3.5 bg-slate-900 text-white rounded-xl font-bold hover:bg-slate-800 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      Continue to Payment →
                    </button>
                    <button
                      onClick={() => setStep('cart')}
                      className="w-full py-2.5 text-slate-600 text-sm hover:text-slate-900"
                    >
                      ← Back to Cart
                    </button>
                  </div>
                )}
                {step === 'payment' && (
                  <div className="space-y-3">
                    <button
                      onClick={handlePlaceOrder}
                      disabled={processing}
                      className="w-full py-3.5 bg-[#BFA364] text-white rounded-none font-bold text-xs uppercase tracking-widest hover:bg-[#A68A50] transition-all disabled:opacity-70 flex items-center justify-center gap-2"
                    >
                      {processing ? (
                        <>
                          <svg className="animate-spin w-5 h-5" viewBox="0 0 24 24" fill="none">
                            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"/>
                            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"/>
                          </svg>
                          Processing...
                        </>
                      ) : (
                        `Pay ₹${grandTotal} →`
                      )}
                    </button>
                    <button
                      onClick={() => setStep('details')}
                      className="w-full py-2.5 text-gray-600 text-sm hover:text-gray-900"
                    >
                      ← Back to Details
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
      <AuthModal isOpen={authModalOpen} onClose={() => setAuthModalOpen(false)} />
    </div>
  );
}
