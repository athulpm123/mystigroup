import { Helmet } from 'react-helmet-async';

export default function AboutPage() {
  return (
    <div className="pt-8">
      <Helmet>
        <title>About Us - MystiGifts</title>
        <meta name="description" content="Learn about our story and mission to create the best personalised gifts for your loved ones." />
      </Helmet>
      {/* Hero */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 py-16 text-center pt-24">
        <h1 className="font-headline text-4xl sm:text-5xl text-slate-900 mb-4">
          Made With Love,
          <br />
          <span className="text-[#BFA364]">
            Crafted For You
          </span>
        </h1>
        <p className="text-lg text-slate-500 max-w-2xl mx-auto">
          Every gift we make carries a piece of our heart — and yours.
        </p>
      </section>

      {/* Story */}
      <section className="bg-slate-50 py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6">
          <div className="bg-white rounded-3xl p-8 sm:p-12 shadow-sm">
            <span className="text-sm font-bold text-[#BFA364] uppercase tracking-wider">Our Story</span>
            <h2 className="font-section text-3xl text-slate-900 mt-2 mb-6">The MystiGifts Story</h2>
            <div className="space-y-4 text-slate-600 leading-relaxed">
              <p>
                MystiGifts was born out of a simple belief: that the best gifts are the ones that carry a piece of your heart. We started as a small passionate team with a dream to make every celebration more special.
              </p>
              <p>
                Today, we create premium personalised gifts — from glowing 3D acrylic lamps to custom engraved keepsakes — that celebrate love, friendship, and every special moment in between.
              </p>
              <p>
                Each product is crafted with care, customised to your story, and delivered with love directly to you.
              </p>
            </div>

            <div className="grid sm:grid-cols-3 gap-6 mt-8">
              {[
                { title: 'Made with Love', desc: 'Every piece is personal and crafted with care.' },
                { title: 'Premium Quality', desc: 'We never compromise on the materials we use.' },
                { title: 'Customer First', desc: 'Your happiness is our biggest achievement.' },
              ].map((item, i) => (
                <div key={i} className="text-center p-8 bg-slate-50 border border-slate-100 rounded-none">
                  <h4 className="font-bold text-slate-900">{item.title}</h4>
                  <p className="text-sm text-slate-500 mt-1">{item.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Mission */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6 py-16 text-center">
        <span className="text-sm font-bold text-[#BFA364] uppercase tracking-wider">Our Mission</span>
        <h2 className="font-section text-2xl sm:text-3xl text-slate-900 mt-4 italic">
          "To make every moment unforgettable with gifts that tell your story."
        </h2>
        <p className="text-slate-500 mt-4 max-w-xl mx-auto">
          We believe the most meaningful gifts are the ones that are personalised — carrying names, dates, and memories that last forever.
        </p>
      </section>

      {/* Stats */}
      <section className="bg-slate-900 text-white py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-8 text-center">
            {[
              { num: '500+', label: 'Happy Customers' },
              { num: '1000+', label: 'Gifts Delivered' },
              { num: '4.8★', label: 'Average Rating' },
              { num: '100%', label: 'Handcrafted' },
            ].map((stat, i) => (
              <div key={i}>
                <div className="font-headline text-3xl sm:text-4xl">{stat.num}</div>
                <div className="text-slate-400 text-sm mt-1">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
