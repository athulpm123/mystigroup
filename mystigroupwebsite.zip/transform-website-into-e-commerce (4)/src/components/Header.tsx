import { useState, useEffect, useSyncExternalStore } from 'react';
import { getCartCount, subscribeToCart } from '../store/cartStore';
import { NavLink, Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';
import AuthModal from './AuthModal';
import { UserCircle, LogOut } from 'lucide-react';

interface HeaderProps {
  onCartClick: () => void;
}

export default function Header({ onCartClick }: HeaderProps) {
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const { user } = useAuth();
  const navigate = useNavigate();

  const cartCount = useSyncExternalStore(subscribeToCart, getCartCount);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleSignOut = async () => {
    await supabase.auth.signOut();
    navigate('/');
  };

  const navItems = [
    { id: '/', label: 'Home' },
    { id: '/shop', label: 'Shop' },
    { id: '/track-order', label: 'Track Order' },
    { id: '/about', label: 'About' },
    { id: '/contact', label: 'Contact' },
  ];

  return (
    <>
      <header
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          scrolled ? 'bg-white/95 backdrop-blur-md shadow-lg' : 'bg-white/80 backdrop-blur-sm'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <Link to="/" className="flex items-center gap-3 group">
              <div className="relative">
                <div className="w-10 h-10 border border-[#BFA364] flex items-center justify-center transition-all duration-500 group-hover:rotate-45">
                  <div className="w-6 h-6 bg-[#BFA364] opacity-20 absolute" />
                  <span className="text-[#BFA364] text-lg font-headline">M</span>
                </div>
              </div>
              <div className="flex flex-col">
                <span className="font-headline text-xl tracking-[0.1em] text-slate-900 leading-none">
                  MYSTI<span className="text-[#BFA364]">GIFTS</span>
                </span>
                <span className="text-[8px] uppercase tracking-[0.4em] text-slate-400 font-bold mt-1">
                  Atelier of Memories
                </span>
              </div>
            </Link>

            {/* Desktop Nav */}
            <nav className="hidden md:flex items-center gap-1">
              {navItems.map((item) => (
                <NavLink
                  key={item.id}
                  to={item.id}
                  className={({ isActive }) => `px-4 py-2 rounded-full text-sm font-semibold transition-all ${
                    isActive
                      ? 'bg-slate-900 text-white shadow-md'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                  }`}
                >
                  {item.label}
                </NavLink>
              ))}
            </nav>

            {/* Right side */}
            <div className="flex items-center gap-3">
              {/* Profile/Auth button */}
              {user ? (
                <div className="hidden md:flex items-center gap-2">
                  <Link to="/profile" className="text-sm font-semibold text-slate-700 hover:text-[#BFA364] flex items-center gap-1">
                    <UserCircle className="w-5 h-5" />
                    <span>Profile</span>
                  </Link>
                  <button onClick={handleSignOut} className="p-2 text-slate-500 hover:text-red-500 transition-colors" title="Sign Out">
                    <LogOut className="w-5 h-5" />
                  </button>
                </div>
              ) : (
                <button
                  onClick={() => setAuthModalOpen(true)}
                  className="hidden md:flex px-6 py-2 text-[10px] font-bold uppercase tracking-widest text-[#BFA364] border border-[#BFA364] rounded-none hover:bg-[#BFA364] hover:text-white transition-all"
                >
                  Sign In
                </button>
              )}

              {/* Cart button */}
              <button
                onClick={onCartClick}
                className="relative p-2 hover:bg-slate-50 transition-colors"
              >
                <svg className="w-5 h-5 text-slate-800" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" />
                </svg>
                {cartCount > 0 && (
                  <span className="absolute top-1 right-1 bg-[#BFA364] text-white text-[8px] w-4 h-4 rounded-full flex items-center justify-center font-bold">
                    {cartCount}
                  </span>
                )}
              </button>

              {/* Mobile menu button */}
              <button
                onClick={() => setMenuOpen(!menuOpen)}
                className="md:hidden p-2 rounded-lg hover:bg-gray-100"
              >
                {menuOpen ? (
                  <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
                  </svg>
                ) : (
                  <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M4 6h16M4 12h16M4 18h16" />
                  </svg>
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Nav */}
        {menuOpen && (
          <div className="md:hidden bg-white border-t shadow-lg">
            <div className="px-4 py-3 space-y-1">
              {navItems.map((item) => (
                <NavLink
                  key={item.id}
                  to={item.id}
                  onClick={() => setMenuOpen(false)}
                  className={({ isActive }) => `block w-full text-left px-4 py-3 rounded-lg text-sm font-semibold transition-all ${
                    isActive
                      ? 'bg-slate-900 text-white'
                      : 'text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  {item.label}
                </NavLink>
              ))}
              {/* Mobile Auth */}
              <div className="border-t pt-2 mt-2">
                {user ? (
                  <>
                    <Link
                      to="/profile"
                      onClick={() => setMenuOpen(false)}
                      className="block w-full text-left px-4 py-3 rounded-lg text-sm font-semibold text-slate-700 hover:bg-slate-50"
                    >
                      Profile & Orders
                    </Link>
                    <button
                      onClick={() => { handleSignOut(); setMenuOpen(false); }}
                      className="block w-full text-left px-4 py-3 rounded-lg text-sm font-semibold text-red-600 hover:bg-red-50"
                    >
                      Sign Out
                    </button>
                  </>
                ) : (
                  <button
                    onClick={() => { setAuthModalOpen(true); setMenuOpen(false); }}
                    className="block w-full text-center px-4 py-3 rounded-lg text-sm font-semibold text-[#BFA364] border border-[#BFA364]/20 mt-2 hover:bg-[#BFA364]/10"
                  >
                    Sign In / Sign Up
                  </button>
                )}
              </div>
            </div>
          </div>
        )}
      </header>

      <AuthModal isOpen={authModalOpen} onClose={() => setAuthModalOpen(false)} />
    </>
  );
}
