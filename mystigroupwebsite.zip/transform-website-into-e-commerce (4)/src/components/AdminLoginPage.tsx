import { useState } from 'react';
import { supabase } from '../lib/supabase';
import { Helmet } from 'react-helmet-async';
import { Lock, User, Eye, EyeOff } from 'lucide-react';

interface AdminLoginPageProps {
  onLoginSuccess: () => void;
}

export default function AdminLoginPage({ onLoginSuccess }: AdminLoginPageProps) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    const cleanPassword = password.trim();

    // 1. Secondary Hardcoded Security Key Check
    if (cleanPassword !== 'mystigifts@1212') {
      setError('Invalid Security Key. Decryption failed.');
      setLoading(false);
      return;
    }

    // 2. Administrator Email Check
    if (email.trim() !== 'athulpm42@gmail.com') {
      setError('Unauthorized access. This area is restricted to the master administrator.');
      setLoading(false);
      return;
    }

    // 3. Local Bypass for Master Admin
    // If the above hardcoded checks pass, we allow entry immediately
    onLoginSuccess();
    setLoading(false);
    return;
  };

  return (
    <div className="min-h-screen bg-slate-950 flex items-center justify-center p-4">
      <Helmet>
        <title>Secure Vault Access - MystiGifts</title>
      </Helmet>

      <div className="max-w-md w-full bg-slate-900 border border-slate-800 rounded-3xl p-8 shadow-2xl relative overflow-hidden">
        <div className="absolute -top-24 -right-24 w-48 h-48 bg-[#BFA364]/10 blur-3xl rounded-full" />
        
        <div className="relative z-10">
          <div className="w-16 h-16 bg-[#BFA364]/10 border border-[#BFA364]/20 rounded-2xl flex items-center justify-center mx-auto mb-6">
            <Lock className="w-8 h-8 text-[#BFA364]" />
          </div>
          
          <div className="text-center mb-8">
            <h1 className="font-headline text-2xl text-white tracking-widest uppercase">Admin Vault</h1>
            <p className="text-slate-500 text-[10px] font-bold uppercase tracking-[0.3em] mt-2">MystiGifts Proprietary System</p>
          </div>

          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-[10px] font-bold uppercase tracking-widest text-slate-400 mb-2">Administrator Email</label>
              <div className="relative">
                <User className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                <input
                  required
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="admin@mystigifts.com"
                  className="w-full bg-slate-950 border border-slate-800 text-white pl-12 pr-4 py-3 rounded-xl outline-none focus:ring-2 focus:ring-[#BFA364] transition-all"
                />
              </div>
            </div>

            <div>
              <label className="block text-[10px] font-bold uppercase tracking-widest text-slate-400 mb-2">Security Key</label>
              <div className="relative">
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                <input
                  required
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full bg-slate-950 border border-slate-800 text-white pl-12 pr-12 py-3 rounded-xl outline-none focus:ring-2 focus:ring-[#BFA364] transition-all"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-500 hover:text-[#BFA364]"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {error && (
              <div className="p-3 bg-red-500/10 border border-red-500/20 rounded-xl text-red-500 text-xs font-bold text-center">
                {error}
              </div>
            )}

            <button
              disabled={loading}
              type="submit"
              className="w-full py-4 bg-[#BFA364] text-white rounded-xl font-bold text-xs uppercase tracking-[0.2em] hover:bg-[#A68A50] transition-all shadow-xl shadow-[#BFA364]/20 flex items-center justify-center gap-2"
            >
              {loading ? <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : 'Decrypt & Access'}
            </button>

            <button
              type="button"
              onClick={async () => {
                if (!email || email.trim() !== 'athulpm42@gmail.com') return alert('Please enter the master admin email first.');
                setLoading(true);
                const { error } = await supabase.auth.resetPasswordForEmail(email, {
                  redirectTo: window.location.origin + '/admin',
                });
                if (error) alert(error.message);
                else alert('Security Reset Link Sent! Please check your email to set your new key.');
                setLoading(false);
              }}
              className="w-full mt-2 py-2 text-slate-500 hover:text-[#BFA364] text-[10px] font-bold uppercase tracking-widest transition-colors"
            >
              Forgot Key? / Reset Vault
            </button>

            <button
              type="button"
              onClick={async () => {
                if (email.trim() !== 'athulpm42@gmail.com') return alert('Only the master admin can initialize the vault.');
                setLoading(true);
                const { error } = await supabase.auth.signUp({ email: email.trim(), password: password.trim() });
                if (error) alert(error.message);
                else alert('Vault Initialized! Please check your email to confirm, then try logging in again.');
                setLoading(false);
              }}
              className="w-full mt-1 py-2 text-slate-600 hover:text-slate-400 text-[9px] font-bold uppercase tracking-widest transition-colors"
            >
              First-Time Setup
            </button>
          </form>
          
          <div className="mt-8 text-center">
            <p className="text-[10px] text-slate-600 font-bold uppercase tracking-widest">
              Authorized Personnel Only
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
