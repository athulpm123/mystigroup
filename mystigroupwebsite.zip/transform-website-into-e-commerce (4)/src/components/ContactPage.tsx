import { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import { supabase } from '../lib/supabase';

export default function ContactPage() {
  const [formData, setFormData] = useState({ name: '', phone: '', email: '', message: '' });
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const { error } = await supabase.from('contact_messages').insert([
        {
          name: formData.name,
          email: formData.email,
          message: `${formData.message} (Phone: ${formData.phone})`,
        },
      ]);

      if (error) throw error;

      setSubmitted(true);
      setFormData({ name: '', phone: '', email: '', message: '' });
      setTimeout(() => setSubmitted(false), 5000);
    } catch (err: any) {
      console.error('Error sending message:', err);
      alert('Failed to send message: ' + err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="pt-8">
      <Helmet>
        <title>Contact Us - MystiGifts</title>
        <meta name="description" content="Get in touch with MystiGifts for custom requests, order tracking, and support." />
      </Helmet>
      <section className="max-w-7xl mx-auto px-4 sm:px-6 py-16">
        <div className="text-center mb-12">
          <div className="w-16 h-16 bg-slate-50 border border-slate-100 flex items-center justify-center mx-auto mb-6 rounded-full">
            <svg className="w-8 h-8 text-[#BFA364]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
            </svg>
          </div>
          <h1 className="font-headline text-4xl text-slate-900 mb-3">Get In Touch</h1>
          <p className="text-gray-500 max-w-xl mx-auto">
            Have a question or custom request? We'd love to hear from you!
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-12 max-w-5xl mx-auto">
          {/* Contact Info */}
          <div className="space-y-8">
            <div>
              <h2 className="font-section text-2xl text-slate-900 mb-6">Contact Information</h2>
              <div className="space-y-5">
                {[
                  { label: 'Phone / WhatsApp', value: '+91 80784 41493', href: 'tel:+918078441493' },
                  { label: 'Email', value: 'mystigifts@gmail.com', href: 'mailto:mystigifts@gmail.com' },
                  { label: 'Instagram', value: '@mystigifts_official', href: 'https://www.instagram.com/mystigifts_official' },
                  { label: 'Location', value: 'India — We ship nationwide', href: '#' },
                ].map((item, i) => (
                  <a
                    key={i}
                    href={item.href}
                    target={item.href.startsWith('http') ? '_blank' : undefined}
                    rel="noreferrer"
                    className="flex items-start gap-4 p-4 rounded-2xl hover:bg-slate-50 transition-colors group"
                  >
                     <div className="w-10 h-10 bg-slate-50 rounded-full flex items-center justify-center text-[#BFA364] group-hover:bg-[#BFA364] group-hover:text-white transition-all">
                       <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                         <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                       </svg>
                     </div>
                    <div>
                      <p className="text-sm text-gray-500">{item.label}</p>
                      <p className="font-semibold text-slate-900 group-hover:text-[#BFA364]">{item.value}</p>
                    </div>
                  </a>
                ))}
              </div>
            </div>

            <div className="bg-slate-900 rounded-2xl p-6 text-white">
              <h3 className="font-bold text-lg mb-2">💬 Quick Order on WhatsApp</h3>
              <p className="text-slate-300 text-sm mb-4">
                Want to place a quick order? Message us directly on WhatsApp with your requirements!
              </p>
              <a
                href="https://wa.me/918078441493?text=Hi%20MystiGifts!%20I'm%20interested%20in%20ordering%20a%20personalised%20gift."
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-2 bg-[#BFA364] text-white px-5 py-2.5 rounded-full font-bold text-sm hover:bg-[#A68A50] transition-colors"
              >
                Chat on WhatsApp
              </a>
            </div>
          </div>

          {/* Contact Form */}
          <div className="bg-white rounded-2xl border p-6 sm:p-8 shadow-sm">
            <h3 className="text-xl font-bold text-gray-900 mb-6">Send us a message</h3>
            {submitted && (
              <div className="mb-4 p-4 bg-green-50 text-green-700 rounded-xl text-sm font-medium">
                Message sent successfully! We'll get back to you soon.
              </div>
            )}
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Your Name</label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  required
                  placeholder="Enter your name"
                  className="w-full px-4 py-2.5 border rounded-xl focus:ring-2 focus:ring-[#BFA364] outline-none"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Phone Number</label>
                <input
                  type="tel"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  required
                  placeholder="+91 XXXXX XXXXX"
                  className="w-full px-4 py-2.5 border rounded-xl focus:ring-2 focus:ring-[#BFA364] outline-none"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Email</label>
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  placeholder="your@email.com"
                  className="w-full px-4 py-2.5 border rounded-xl focus:ring-2 focus:ring-[#BFA364] outline-none"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Message</label>
                <textarea
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  required
                  rows={4}
                  placeholder="Tell us about your requirements..."
                  className="w-full px-4 py-2.5 border rounded-xl focus:ring-2 focus:ring-[#BFA364] outline-none resize-none"
                />
              </div>
              <button
                type="submit"
                disabled={loading}
                className="w-full py-3 bg-[#BFA364] text-white rounded-xl font-bold hover:bg-[#A68A50] transition-all disabled:opacity-70 flex items-center justify-center gap-2"
              >
                {loading ? (
                  <>
                    <svg className="animate-spin h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    Sending...
                  </>
                ) : (
                  'Send Message'
                )}
              </button>
            </form>
          </div>
        </div>
      </section>
    </div>
  );
}
