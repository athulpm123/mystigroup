import { useState, useMemo, useEffect } from 'react';
import { categories, type Product } from '../data/products';
import CategoryBar from './CategoryBar';
import ProductCard from './ProductCard';
import ProductDetail from './ProductDetail';
import { Helmet } from 'react-helmet-async';
import { supabase } from '../lib/supabase';

interface ShopPageProps {
  onGoToCart: () => void;
  initialCategory?: string | null;
}

export default function ShopPage({ onGoToCart, initialCategory = null }: ShopPageProps) {
  const [dbProducts, setDbProducts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(initialCategory);
  const [selectedProduct, setSelectedProduct] = useState<any | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<'popular' | 'low-high' | 'high-low' | 'discount'>('popular');

  useEffect(() => {
    setSelectedCategory(initialCategory);
  }, [initialCategory]);

  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = async () => {
    setLoading(true);
    const { data } = await supabase
      .from('products')
      .select('*')
      .order('created_at', { ascending: false });
    
    if (data) {
      // Map database names to frontend names if different
      const mapped = data.map(p => ({
        ...p,
        image: p.image_url, // Use image_url from DB
        originalPrice: p.original_price,
        customizable: p.is_customizable, // FIX: Match DB field to frontend
        features: ['Premium Quality', 'Handcrafted', 'Fast Shipping'], // Fallback features
        customizationOptions: p.customization_options || []
      }));
      setDbProducts(mapped);
    }
    setLoading(false);
  };

  const filteredProducts = useMemo(() => {
    let filtered = dbProducts;

    if (selectedCategory) {
      filtered = filtered.filter((p) => p.category === selectedCategory);
    }

    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      filtered = filtered.filter(
        (p) =>
          p.name.toLowerCase().includes(q) ||
          p.description.toLowerCase().includes(q) ||
          p.category.toLowerCase().includes(q)
      );
    }

    switch (sortBy) {
      case 'low-high':
        return [...filtered].sort((a, b) => a.price - b.price);
      case 'high-low':
        return [...filtered].sort((a, b) => b.price - a.price);
      case 'discount':
        return [...filtered].sort((a, b) => {
          const discA = (a.originalPrice - a.price) / a.originalPrice;
          const discB = (b.originalPrice - b.price) / b.originalPrice;
          return discB - discA;
        });
      default:
        return filtered;
    }
  }, [dbProducts, selectedCategory, searchQuery, sortBy]);

  const currentCat = categories.find((c) => c.id === selectedCategory);

  return (
    <div>
      <Helmet>
        <title>{currentCat ? `${currentCat.name} - MystiGifts` : 'Shop Personalised Gifts - MystiGifts'}</title>
        <meta name="description" content={currentCat ? currentCat.description : 'Browse our collection of personalised gifts, acrylic lamps, and photo frames.'} />
      </Helmet>
      {/* Category Bar */}
      <CategoryBar selectedCategory={selectedCategory} onSelectCategory={setSelectedCategory} />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
        {/* Category header */}
        {currentCat && (
          <div className="mb-8 text-center pt-8">
            <h2 className="font-headline text-3xl text-slate-900">{currentCat.name}</h2>
            <p className="text-gray-500 mt-2 max-w-xl mx-auto">{currentCat.description}</p>
          </div>
        )}

        {!currentCat && (
          <div className="mb-8 text-center">
            <h2 className="font-headline text-3xl text-slate-900">All Products</h2>
            <p className="text-gray-500 mt-2">Browse our complete collection of personalised gifts</p>
          </div>
        )}

        {/* Search & Sort */}
        <div className="flex flex-col sm:flex-row gap-4 mb-8">
          <div className="relative flex-1">
            <svg className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
            <input
              type="text"
              placeholder="Search gifts..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-3 border border-slate-200 rounded-xl focus:ring-2 focus:ring-amber-500 focus:border-transparent outline-none font-medium"
            />
          </div>
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as typeof sortBy)}
            className="px-4 py-3 border border-slate-200 rounded-xl focus:ring-2 focus:ring-[#BFA364] outline-none bg-white text-slate-700 font-medium"
          >
            <option value="popular">Popular</option>
            <option value="low-high">Price: Low to High</option>
            <option value="high-low">Price: High to Low</option>
            <option value="discount">Best Discount</option>
          </select>
        </div>

        {/* Products count */}
        <p className="text-sm text-gray-500 mb-4">{filteredProducts.length} products found</p>

        {/* Product Grid */}
        {loading ? (
          <div className="flex flex-col items-center justify-center py-20">
            <div className="w-12 h-12 border-4 border-[#BFA364] border-t-transparent rounded-full animate-spin mb-4"></div>
            <p className="text-slate-500 font-medium">Fetching magical gifts...</p>
          </div>
        ) : filteredProducts.length > 0 ? (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
            {filteredProducts.map((product) => (
              <ProductCard
                key={product.id}
                product={product}
                onViewProduct={setSelectedProduct}
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-16">
            <div className="w-12 h-12 bg-slate-100 border border-slate-200 flex items-center justify-center mx-auto mb-4 rounded-full text-slate-400 font-bold">!</div>
            <h3 className="text-xl font-bold text-gray-900">No products found</h3>
            <p className="text-gray-500 mt-2">Try changing your search or category filter</p>
          </div>
        )}
      </div>

      {/* Product Detail Modal */}
      {selectedProduct && (
        <ProductDetail
          product={selectedProduct}
          onClose={() => setSelectedProduct(null)}
          onGoToCart={() => {
            setSelectedProduct(null);
            onGoToCart();
          }}
        />
      )}
    </div>
  );
}
