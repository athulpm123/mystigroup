interface FooterProps {
  onNavigate: (page: string) => void;
}

export default function Footer({ onNavigate }: FooterProps) {
  return (
    <footer className="bg-gray-900 text-white">
      {/* CTA Section */}
      <div className="bg-slate-950 py-12">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 text-center">
          <h2 className="font-headline text-2xl sm:text-3xl mb-3">Ready to Create Something Special?</h2>
          <p className="text-slate-300 mb-6">Browse our collection and find the perfect personalised gift</p>
          <button
            onClick={() => onNavigate('shop')}
            className="px-8 py-3 bg-[#BFA364] text-white rounded-full font-bold hover:bg-[#A68A50] transition-colors"
          >
            Shop Now
          </button>
        </div>
      </div>

      {/* Main Footer */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-12">
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="space-y-4">
              <div className="w-10 h-10 border border-[#BFA364] flex items-center justify-center text-[#BFA364] font-headline">
                M
              </div>
              <span className="text-xl font-headline tracking-widest">MYSTIGIFTS</span>
            <p className="text-gray-400 text-sm">
              Premium personalised gifts crafted with love. Making every moment magical since 2023.
            </p>
            <div className="flex gap-3">
              <a
                href="https://www.instagram.com/mystigifts_official"
                target="_blank"
                rel="noreferrer"
                className="w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center hover:bg-[#BFA364] transition-colors"
              >
                <span className="text-[10px] font-bold">INSTA</span>
              </a>
              <a
                href="https://wa.me/918078441493"
                target="_blank"
                rel="noreferrer"
                className="w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center hover:bg-green-600 transition-colors"
              >
                <span className="text-[10px] font-bold">WA</span>
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-bold mb-4">Quick Links</h4>
            <div className="space-y-2">
              {[
                { label: 'Home', page: 'home' },
                { label: 'Shop', page: 'shop' },
                { label: 'About Us', page: 'about' },
                { label: 'Contact', page: 'contact' },
              ].map((item) => (
                <button
                  key={item.page}
                  onClick={() => onNavigate(item.page)}
                  className="block text-gray-400 hover:text-white text-sm transition-colors"
                >
                  {item.label}
                </button>
              ))}
            </div>
          </div>

          {/* Policies */}
          <div>
            <h4 className="font-bold mb-4">Our Policies</h4>
            <div className="space-y-2">
              {[
                { label: 'Shipping & Delivery', path: '/policies/shipping-policy' },
                { label: 'Refund & Cancellation', path: '/policies/refund-policy' },
                { label: 'Terms & Conditions', path: '/policies/terms' },
                { label: 'Track Your Order', path: '/track-order' },
              ].map((item) => (
                <a
                  key={item.path}
                  href={item.path}
                  className="block text-gray-400 hover:text-white text-sm transition-colors"
                >
                  {item.label}
                </a>
              ))}
            </div>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-bold mb-4">Contact Us</h4>
            <div className="space-y-3 text-sm text-gray-400">
              <p>Phone: +91 80784 41493</p>
              <p>Email: mystigifts@gmail.com</p>
              <p>Location: India — Nationwide Shipping</p>
            </div>
            <div className="mt-4 flex flex-wrap gap-2">
              <span className="text-xs bg-gray-800 px-3 py-1 rounded-none border border-gray-700">SECURE PAYMENTS</span>
              <span className="text-xs bg-gray-800 px-3 py-1 rounded-none border border-gray-700">FREE SHIPPING</span>
            </div>
          </div>
        </div>

        {/* Payment icons */}
        <div className="border-t border-gray-800 mt-8 pt-8">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <p className="text-gray-500 text-sm">
              © 2025 MystiGifts. All rights reserved.
            </p>
            <div className="flex items-center gap-3 text-sm text-gray-500">
              <span>Payment powered by</span>
              <span className="bg-gray-800 px-3 py-1 rounded-lg font-bold text-white">Cashfree</span>
              <span className="text-xs">| UPI • Cards • Net Banking</span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
