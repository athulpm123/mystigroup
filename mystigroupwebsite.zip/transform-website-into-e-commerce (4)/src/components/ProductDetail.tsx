import { useState, useEffect } from 'react';
import { Product } from '../data/products';
import { addToCart } from '../store/cartStore';
import { supabase } from '../lib/supabase';
import ReviewSection from './ReviewSection';

interface ProductDetailProps {
  product: Product;
  onClose: () => void;
  onGoToCart: () => void;
}

export default function ProductDetail({ product, onClose, onGoToCart }: ProductDetailProps) {
  const [quantity, setQuantity] = useState(1);
  const [photoPreview, setPhotoPreview] = useState<string>('');
  const [names, setNames] = useState('');
  const [message, setMessage] = useState('');
  const [specialDate, setSpecialDate] = useState('');
  const [additionalNotes, setAdditionalNotes] = useState('');
  const [added, setAdded] = useState(false);
  const [stock, setStock] = useState<number | null>(null);

  useEffect(() => {
    fetchStock();
  }, [product.id]);

  const fetchStock = async () => {
    const { data } = await supabase
      .from('products')
      .select('stock_quantity')
      .eq('id', product.id)
      .single();
    if (data) setStock(data.stock_quantity);
  };

  const discount = Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100);

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setPhotoPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAddToCart = () => {
    addToCart({
      product,
      quantity,
      customization: {
        photoPreview,
        names,
        message,
        specialDate,
        additionalNotes,
      },
    });
    setAdded(true);
    setTimeout(() => setAdded(false), 2000);
  };

  const handleBuyNow = () => {
    addToCart({
      product,
      quantity,
      customization: {
        photoPreview,
        names,
        message,
        specialDate,
        additionalNotes,
      },
    });
    onGoToCart();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto">
      <div className="fixed inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
      <div className="relative min-h-screen flex items-start justify-center p-4 pt-10 pb-20">
        <div className="relative bg-white rounded-3xl shadow-2xl max-w-4xl w-full overflow-hidden flex flex-col">
          {/* Close button */}
          <button
            onClick={onClose}
            className="absolute top-4 right-4 z-10 p-2 bg-white/80 backdrop-blur-sm rounded-full shadow hover:bg-white transition-colors"
          >
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>

          <div className="overflow-y-auto max-h-[90vh]">
            <div className="grid md:grid-cols-2">
              {/* Left: Product visual */}
              <div className="relative bg-gradient-to-br from-slate-50 to-slate-100 flex flex-col items-center justify-center min-h-[300px]">
                <img
                  src={product.image}
                  alt={product.name}
                  className="h-full min-h-[420px] w-full object-cover"
                />
                {product.badge && (
                  <span className="absolute top-6 left-6 bg-slate-900 text-white text-sm font-bold px-4 py-1.5 rounded-full">
                    {product.badge}
                  </span>
                )}
                <div className="absolute bottom-6 left-6 right-6 flex flex-wrap gap-2 justify-center">
                  {product.features.map((f, i) => (
                    <span key={i} className="text-[10px] uppercase tracking-widest bg-white text-slate-400 px-3 py-1 rounded-none border border-slate-100 shadow-sm">
                      {f}
                    </span>
                  ))}
                </div>
              </div>

              {/* Right: Product details */}
              <div className="p-6 sm:p-8 space-y-5">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="px-2 py-0.5 bg-amber-50 text-amber-600 text-[10px] font-bold uppercase rounded tracking-wider">
                      Handcrafted
                    </span>
                    {stock !== null && stock < 10 && (
                      <span className="px-2 py-0.5 bg-red-50 text-red-600 text-[10px] font-bold uppercase rounded tracking-wider animate-pulse">
                        Low Stock: Only {stock} left!
                      </span>
                    )}
                  </div>
                  <h2 className="font-headline text-3xl text-slate-900">{product.name}</h2>
                  <p className="text-slate-500 mt-2 leading-relaxed">{product.description}</p>
                </div>

                {/* Price */}
                <div className="flex items-center gap-3">
                  <span className="text-3xl font-extrabold text-slate-900">₹{product.price}</span>
                  <span className="text-lg text-slate-400 line-through font-medium">₹{product.originalPrice}</span>
                  <span className="bg-[#BFA364]/10 text-[#BFA364] text-sm font-bold px-3 py-1 rounded-full">
                    {discount}% OFF
                  </span>
                </div>

                {/* Customization Section */}
                {product.customizable && (
                  <div className="space-y-4 border-t pt-5">
                    <h3 className="font-bold text-slate-900 flex items-center gap-2">
                      Personalize Your Selection
                    </h3>

                    {/* Photo Upload */}
                    {product.customizationOptions.some((o) =>
                      o.toLowerCase().includes('photo')
                    ) && (
                      <div>
                        <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">
                          Upload Asset
                        </label>
                        <label className="flex-1 cursor-pointer">
                          <div className="border-2 border-dashed border-slate-200 rounded-2xl p-6 text-center hover:border-[#BFA364] transition-colors bg-slate-50/50">
                            {photoPreview ? (
                              <img
                                src={photoPreview}
                                alt="Preview"
                                className="w-24 h-24 object-cover rounded-xl mx-auto shadow-lg"
                              />
                            ) : (
                              <div className="text-slate-400">
                                <span className="text-sm font-bold uppercase tracking-widest">Select Image</span>
                              </div>
                            )}
                          </div>
                          <input type="file" accept="image/*" onChange={handlePhotoUpload} className="hidden" />
                        </label>
                      </div>
                    )}

                    {/* Names */}
                    {product.customizationOptions.some((o) =>
                      o.toLowerCase().includes('name')
                    ) && (
                      <div>
                        <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">Engraving Name(s)</label>
                        <input
                          type="text"
                          placeholder="e.g. Alexander & Sophia"
                          value={names}
                          onChange={(e) => setNames(e.target.value)}
                          className="w-full px-5 py-3 border border-slate-200 rounded-xl focus:ring-2 focus:ring-[#BFA364] outline-none font-medium"
                        />
                      </div>
                    )}

                    {/* Special Date */}
                    {product.customizationOptions.some((o) =>
                      o.toLowerCase().includes('date')
                    ) && (
                      <div>
                        <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">Special Date</label>
                        <input
                          type="date"
                          value={specialDate}
                          onChange={(e) => setSpecialDate(e.target.value)}
                          className="w-full px-5 py-3 border border-slate-200 rounded-xl focus:ring-2 focus:ring-[#BFA364] outline-none font-medium"
                        />
                      </div>
                    )}

                    {/* Custom Text (Single Line) */}
                    {product.customizationOptions.some((o) =>
                      o.toLowerCase() === 'custom text'
                    ) && (
                      <div>
                        <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">Custom Text</label>
                        <input
                          type="text"
                          placeholder="e.g. MH 01 AB 1234 or Your Name"
                          value={names}
                          onChange={(e) => setNames(e.target.value)}
                          className="w-full px-5 py-3 border border-slate-200 rounded-xl focus:ring-2 focus:ring-[#BFA364] outline-none font-medium"
                        />
                      </div>
                    )}

                    {/* Personal Message (Textarea) */}
                    {product.customizationOptions.some((o) =>
                      o.toLowerCase().includes('message') || o.toLowerCase().includes('quote')
                    ) && (
                      <div>
                        <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">Personal Message</label>
                        <textarea
                          placeholder="Enter your personal message here..."
                          value={message}
                          onChange={(e) => setMessage(e.target.value)}
                          rows={2}
                          className="w-full px-5 py-3 border border-slate-200 rounded-xl focus:ring-2 focus:ring-[#BFA364] outline-none resize-none"
                        />
                      </div>
                    )}
                  </div>
                )}

                {/* Quantity & Actions */}
                <div className="flex flex-col gap-5 pt-5 border-t">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold uppercase tracking-widest text-slate-400">Quantity</span>
                    <div className="flex items-center border border-slate-200 rounded-xl overflow-hidden bg-white">
                      <button onClick={() => setQuantity(Math.max(1, quantity - 1))} className="px-5 py-2 hover:bg-slate-50 font-bold text-slate-400">−</button>
                      <span className="px-6 py-2 font-bold text-slate-900 border-x border-slate-100">{quantity}</span>
                      <button onClick={() => setQuantity(quantity + 1)} className="px-5 py-2 hover:bg-slate-50 font-bold text-slate-400">+</button>
                    </div>
                  </div>

                  <div className="flex flex-col sm:flex-row gap-3">
                    <button
                      onClick={handleAddToCart}
                      className={`flex-1 py-4 px-6 rounded-xl font-bold text-xs uppercase tracking-widest transition-all ${
                        added ? 'bg-slate-800 text-white' : 'border-2 border-slate-900 text-slate-900 hover:bg-slate-900 hover:text-white'
                      }`}
                    >
                      {added ? 'Added to Cart' : 'Add to Cart'}
                    </button>
                    <button
                      onClick={handleBuyNow}
                      className="flex-1 py-4 px-6 bg-[#BFA364] text-white rounded-xl font-bold text-xs uppercase tracking-widest hover:bg-[#A68A50] transition-all shadow-xl shadow-[#BFA364]/20"
                    >
                      Shop Now
                    </button>
                  </div>
                </div>

                {/* Trust Indicators */}
                <div className="grid grid-cols-3 gap-3 py-6">
                  <div className="text-center p-4 bg-slate-50/50 rounded-2xl border border-slate-100">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Global Shipping</span>
                  </div>
                  <div className="text-center p-4 bg-slate-50/50 rounded-2xl border border-slate-100">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Secure SSL</span>
                  </div>
                  <div className="text-center p-4 bg-slate-50/50 rounded-2xl border border-slate-100">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">QC Verified</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Reviews Section at bottom of modal */}
            <div className="bg-slate-50 px-6 sm:px-8 py-12">
              <ReviewSection productId={product.id} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
