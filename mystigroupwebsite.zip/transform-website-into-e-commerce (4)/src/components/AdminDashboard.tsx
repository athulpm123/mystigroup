import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { Helmet } from 'react-helmet-async';
import { useAuth } from '../contexts/AuthContext';
import { Package, ShoppingBag, Plus, Edit2, Trash2, Save, X, Upload } from 'lucide-react';
import AdminLoginPage from './AdminLoginPage';

export default function AdminDashboard() {
  const { user, loading: authLoading } = useAuth();
  const [isLocalAuthorized, setIsLocalAuthorized] = useState(false);
  const [activeTab, setActiveTab] = useState<'orders' | 'products'>('orders');
  const [orders, setOrders] = useState<any[]>([]);
  const [products, setProducts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [updating, setUpdating] = useState<string | null>(null);
  const [isRefreshing, setIsRefreshing] = useState(false);

  // Product Form State
  const [isEditing, setIsEditing] = useState(false);
  const [editingProduct, setEditingProduct] = useState<any>(null);
  const [uploading, setUploading] = useState(false);

  // Simple admin check + Local Bypass
  const isAdmin = user?.email === 'athulpm42@gmail.com' || isLocalAuthorized;

  useEffect(() => {
    if (isAdmin) {
      if (activeTab === 'orders') fetchOrders();
      if (activeTab === 'products') fetchProducts();
    }
  }, [isAdmin, activeTab, isRefreshing]);

  const fetchOrders = async () => {
    setLoading(true);
    const { data } = await supabase
      .from('orders')
      .select('*, profiles(full_name, phone)')
      .order('created_at', { ascending: false });
    if (data) setOrders(data);
    setLoading(false);
  };

  const fetchProducts = async () => {
    setLoading(true);
    const { data } = await supabase
      .from('products')
      .select('*')
      .order('created_at', { ascending: false });
    if (data) setProducts(data);
    setLoading(false);
  };

  const updateOrderStatus = async (orderId: string, newStatus: string) => {
    setUpdating(orderId);
    const { error } = await supabase.from('orders').update({ status: newStatus }).eq('id', orderId);
    if (!error) setOrders(orders.map(o => o.id === orderId ? { ...o, status: newStatus } : o));
    setUpdating(null);
  };

  const handleProductSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setUpdating('saving-product');
    
    if (editingProduct.id && products.some(p => p.id === editingProduct.id)) {
      // Update
      const { error } = await supabase.from('products').upsert(editingProduct);
      if (!error) {
        setIsEditing(false);
        fetchProducts();
      }
    } else {
      // Create
      const { error } = await supabase.from('products').insert([editingProduct]);
      if (!error) {
        setIsEditing(false);
        fetchProducts();
      }
    }
    setUpdating(null);
  };

  const deleteProduct = async (id: string) => {
    if (!confirm('Are you sure you want to delete this product?')) return;
    const { error } = await supabase.from('products').delete().eq('id', id);
    if (!error) fetchProducts();
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploading(true);
    const fileExt = file.name.split('.').pop();
    const fileName = `${Math.random()}.${fileExt}`;
    const filePath = `product-images/${fileName}`;

    try {
      const { error: uploadError } = await supabase.storage
        .from('product-images')
        .upload(filePath, file);

      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage
        .from('product-images')
        .getPublicUrl(filePath);

      setEditingProduct({ ...editingProduct, image_url: publicUrl });
    } catch (error: any) {
      alert('Error uploading image: ' + error.message);
    } finally {
      setUploading(false);
    }
  };

  if (authLoading) return <div className="min-h-screen flex items-center justify-center bg-slate-950 text-white font-bold tracking-widest uppercase text-xs">Authenticating Vault...</div>;
  
  if (!isAdmin) {
    return <AdminLoginPage onLoginSuccess={() => setIsLocalAuthorized(true)} />;
  }

  return (
    <div className="pt-8 min-h-screen bg-slate-50">
      <Helmet><title>Admin Dashboard - MystiGifts</title></Helmet>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-12">
        <div className="flex flex-col md:flex-row md:items-center justify-between mb-8 gap-4">
          <h1 className="text-3xl font-headline text-slate-900">Admin Dashboard</h1>
          
          <div className="flex bg-white p-1 rounded-xl shadow-sm border">
            <button
              onClick={() => setActiveTab('orders')}
              className={`px-6 py-2 rounded-lg text-sm font-bold flex items-center gap-2 transition-all ${activeTab === 'orders' ? 'bg-slate-900 text-white shadow-md' : 'text-slate-500 hover:text-slate-900'}`}
            >
              <ShoppingBag className="w-4 h-4" /> Orders
            </button>
            <button
              onClick={() => setActiveTab('products')}
              className={`px-6 py-2 rounded-lg text-sm font-bold flex items-center gap-2 transition-all ${activeTab === 'products' ? 'bg-slate-900 text-white shadow-md' : 'text-slate-500 hover:text-slate-900'}`}
            >
              <Package className="w-4 h-4" /> Products
            </button>
          </div>
        </div>

        {activeTab === 'orders' && (
          <div className="bg-white rounded-2xl shadow-sm border overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead className="bg-slate-50 border-b">
                  <tr>
                    <th className="px-6 py-4 font-semibold text-slate-600">Order ID</th>
                    <th className="px-6 py-4 font-semibold text-slate-600">Customer</th>
                    <th className="px-6 py-4 font-semibold text-slate-600">Total</th>
                    <th className="px-6 py-4 font-semibold text-slate-600">Status</th>
                    <th className="px-6 py-4 font-semibold text-slate-600">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y">
                  {loading ? (
                    <tr><td colSpan={5} className="px-6 py-8 text-center text-slate-500">Loading orders...</td></tr>
                  ) : orders.map(order => (
                    <tr key={order.id} className="hover:bg-slate-50 transition-colors">
                      <td className="px-6 py-4 font-mono text-xs text-slate-500">{order.id.slice(0, 8)}</td>
                      <td className="px-6 py-4">
                        <div className="font-semibold text-slate-900">{order.shipping_details?.fullName}</div>
                        <div className="text-xs text-slate-500">{order.shipping_details?.phone}</div>
                      </td>
                      <td className="px-6 py-4 font-semibold">₹{order.total_amount}</td>
                      <td className="px-6 py-4">
                        <span className={`px-2.5 py-1 rounded-full text-xs font-bold uppercase ${order.status === 'pending' ? 'bg-[#BFA364]/10 text-[#BFA364]' : 'bg-green-100 text-green-700'}`}>
                          {order.status}
                        </span>
                      </td>
                      <td className="px-6 py-4 flex items-center gap-3">
                        <select
                          disabled={updating === order.id}
                          value={order.status}
                          onChange={(e) => updateOrderStatus(order.id, e.target.value)}
                          className="px-3 py-1.5 border rounded-lg text-sm bg-white outline-none focus:ring-2 focus:ring-[#BFA364]"
                        >
                          <option value="pending">Pending</option>
                          <option value="paid">Paid</option>
                          <option value="shipped">Shipped</option>
                          <option value="delivered">Delivered</option>
                        </select>
                        <a
                          href={`https://wa.me/${order.shipping_details?.phone?.replace(/\D/g, '')}?text=${encodeURIComponent(
                            `Hello ${order.shipping_details?.fullName}, this is from MystiGifts! Just updating you that your order #${order.id.slice(0,8)} is now ${order.status.toUpperCase()}.`
                          )}`}
                          target="_blank"
                          rel="noreferrer"
                          className="p-2 bg-green-50 text-green-600 rounded-lg hover:bg-green-100 transition-colors"
                          title="Message on WhatsApp"
                        >
                          <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                            <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/>
                          </svg>
                        </a>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {activeTab === 'products' && (
          <div className="space-y-6">
            <div className="flex justify-end">
              <button
                onClick={() => {
                  setEditingProduct({ name: '', price: 0, original_price: 0, stock_quantity: 50, description: '', category: 'acrylic-keychains', is_customizable: true, customization_options: [] });
                  setIsEditing(true);
                }}
                className="bg-[#BFA364] text-white px-6 py-2.5 rounded-xl font-bold flex items-center gap-2 hover:bg-[#A68A50] transition-all shadow-lg shadow-[#BFA364]/20"
              >
                <Plus className="w-5 h-5" /> Add New Product
              </button>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {loading ? (
                <p>Loading products...</p>
              ) : products.map(product => (
                <div key={product.id} className="bg-white rounded-2xl border p-4 shadow-sm group">
                  <div className="aspect-square rounded-xl bg-slate-100 overflow-hidden mb-4 relative">
                    <img src={product.image_url} alt={product.name} className="w-full h-full object-cover" />
                    <div className="absolute top-2 right-2 flex gap-2">
                      <button onClick={() => { setEditingProduct(product); setIsEditing(true); }} className="p-2 bg-white/90 backdrop-blur rounded-lg text-slate-600 hover:text-[#BFA364] shadow-sm"><Edit2 className="w-4 h-4" /></button>
                      <button onClick={() => deleteProduct(product.id)} className="p-2 bg-white/90 backdrop-blur rounded-lg text-slate-600 hover:text-red-600 shadow-sm"><Trash2 className="w-4 h-4" /></button>
                    </div>
                  </div>
                  <h3 className="font-bold text-slate-900 mb-1">{product.name}</h3>
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-[#BFA364] text-lg">₹{product.price}</span>
                    <span className={`text-xs font-bold px-2 py-1 rounded-lg ${product.stock_quantity < 10 ? 'bg-red-50 text-red-600' : 'bg-slate-50 text-slate-600'}`}>
                      Stock: {product.stock_quantity}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Product Edit Modal */}
        {isEditing && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
            <div className="bg-white rounded-3xl w-full max-w-2xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
              <div className="p-6 border-b flex items-center justify-between bg-slate-50">
                <h2 className="text-xl font-bold text-slate-900">{editingProduct?.id ? 'Edit Product' : 'Add New Product'}</h2>
                <button onClick={() => setIsEditing(false)} className="p-2 hover:bg-slate-200 rounded-full transition-colors"><X className="w-5 h-5" /></button>
              </div>
              
              <form onSubmit={handleProductSubmit} className="p-6 overflow-y-auto space-y-5">
                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-bold text-slate-700 mb-1">Product ID (Unique)</label>
                    <input
                      type="text"
                      disabled={!!editingProduct.id}
                      value={editingProduct.id || ''}
                      onChange={e => setEditingProduct({...editingProduct, id: e.target.value})}
                      className="w-full px-4 py-2.5 border rounded-xl outline-none focus:ring-2 focus:ring-amber-500"
                      placeholder="e.g. custom-keychain-01"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-slate-700 mb-1">Product Name</label>
                    <input
                      type="text"
                      value={editingProduct.name}
                      onChange={e => setEditingProduct({...editingProduct, name: e.target.value})}
                      className="w-full px-4 py-2.5 border rounded-xl outline-none focus:ring-2 focus:ring-amber-500"
                      required
                    />
                  </div>
                </div>

                <div className="grid sm:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-sm font-bold text-slate-700 mb-1">Price (₹)</label>
                    <input
                      type="number"
                      value={editingProduct.price}
                      onChange={e => setEditingProduct({...editingProduct, price: Number(e.target.value)})}
                      className="w-full px-4 py-2.5 border rounded-xl outline-none focus:ring-2 focus:ring-amber-500"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-slate-700 mb-1">Original Price (₹)</label>
                    <input
                      type="number"
                      value={editingProduct.original_price}
                      onChange={e => setEditingProduct({...editingProduct, original_price: Number(e.target.value)})}
                      className="w-full px-4 py-2.5 border rounded-xl outline-none focus:ring-2 focus:ring-amber-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-slate-700 mb-1">Stock Quantity</label>
                    <input
                      type="number"
                      value={editingProduct.stock_quantity}
                      onChange={e => setEditingProduct({...editingProduct, stock_quantity: Number(e.target.value)})}
                      className="w-full px-4 py-2.5 border rounded-xl outline-none focus:ring-2 focus:ring-amber-500"
                      required
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-1">Description</label>
                  <textarea
                    value={editingProduct.description}
                    onChange={e => setEditingProduct({...editingProduct, description: e.target.value})}
                    rows={3}
                    className="w-full px-4 py-2.5 border rounded-xl outline-none focus:ring-2 focus:ring-[#BFA364] resize-none"
                    required
                  />
                </div>

                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-bold text-slate-700 mb-1">Category</label>
                    <select
                      value={editingProduct.category}
                      onChange={e => setEditingProduct({...editingProduct, category: e.target.value})}
                      className="w-full px-4 py-2.5 border rounded-xl outline-none focus:ring-2 focus:ring-[#BFA364] bg-white"
                      required
                    >
                      <option value="acrylic-keychains">Acrylic Keychains</option>
                      <option value="necklaces">Engraved Necklaces</option>
                      <option value="car-tags">Car Tags</option>
                      <option value="acrylic-lamps">3D Acrylic Lamps</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-slate-700 mb-1">Customization (Comma Separated)</label>
                    <input
                      type="text"
                      value={editingProduct.customization_options?.join(', ') || ''}
                      onChange={e => setEditingProduct({...editingProduct, customization_options: e.target.value.split(',').map(s => s.trim())})}
                      className="w-full px-4 py-2.5 border rounded-xl outline-none focus:ring-2 focus:ring-[#BFA364]"
                      placeholder="e.g. Photo, Names, Special Date"
                    />
                  </div>
                </div>

                <div className="flex items-center gap-3 p-4 bg-slate-50 rounded-2xl border">
                  <input
                    type="checkbox"
                    id="is_customizable"
                    checked={editingProduct.is_customizable}
                    onChange={e => setEditingProduct({...editingProduct, is_customizable: e.target.checked})}
                    className="w-5 h-5 accent-[#BFA364]"
                  />
                  <label htmlFor="is_customizable" className="text-sm font-bold text-slate-900 cursor-pointer">
                    Enable Customer Personalization
                  </label>
                </div>

                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-1">Product Image</label>
                  <div className="flex items-center gap-4">
                    <div className="w-24 h-24 bg-slate-100 rounded-xl overflow-hidden border">
                      {editingProduct.image_url ? (
                        <img src={editingProduct.image_url} className="w-full h-full object-cover" />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center text-slate-300"><Plus /></div>
                      )}
                    </div>
                    <label className="flex-1 cursor-pointer">
                      <div className="border-2 border-dashed border-slate-200 rounded-xl p-4 text-center hover:bg-slate-50">
                        {uploading ? 'Uploading...' : 'Click to Upload Image'}
                        <input type="file" className="hidden" accept="image/*" onChange={handleImageUpload} />
                      </div>
                    </label>
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={updating === 'saving-product'}
                  className="w-full py-4 bg-slate-900 text-white rounded-2xl font-bold flex items-center justify-center gap-2 hover:bg-slate-800 transition-all shadow-xl"
                >
                  <Save className="w-5 h-5" /> {updating === 'saving-product' ? 'Saving...' : 'Save Product Details'}
                </button>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

