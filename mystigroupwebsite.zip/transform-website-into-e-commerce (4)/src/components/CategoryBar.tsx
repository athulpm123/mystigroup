import { categories } from '../data/products';
import { motion } from 'framer-motion';

interface CategoryBarProps {
  selectedCategory: string | null;
  onSelectCategory: (categoryId: string | null) => void;
}

export default function CategoryBar({ selectedCategory, onSelectCategory }: CategoryBarProps) {
  // Create a duplicated list for infinite scroll effect
  const allItems = [{ id: null, name: 'All Products' }, ...categories];

  return (
    <section className="py-4 bg-white sticky top-16 z-40 border-b overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="animate-marquee gap-3">
          {/* Render twice for seamless loop */}
          {[...allItems, ...allItems, ...allItems].map((item, index) => (
            <button
              key={`${item.id}-${index}`}
              onClick={() => onSelectCategory(item.id)}
              className={`flex-shrink-0 px-8 py-3 text-[10px] font-bold uppercase tracking-widest transition-all whitespace-nowrap border mx-1.5 ${
                selectedCategory === item.id
                  ? 'bg-[#BFA364] text-white border-[#BFA364] shadow-xl shadow-[#BFA364]/20'
                  : 'bg-white text-slate-400 border-slate-100 hover:text-slate-900 hover:border-slate-300'
              }`}
            >
              {item.name}
            </button>
          ))}
        </div>
      </div>
    </section>
  );
}
