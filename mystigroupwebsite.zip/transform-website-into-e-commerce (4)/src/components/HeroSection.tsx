import { useEffect, useState } from 'react';
import { products } from '../data/products';
import { motion, AnimatePresence } from 'framer-motion';

interface HeroProps {
  onShopNow: () => void;
}

const letterAnimation = {
  hidden: { opacity: 0, y: 50 },
  visible: { opacity: 1, y: 0 },
};

const containerAnimation = {
  visible: {
    transition: {
      staggerChildren: 0.03,
    },
  },
};

export default function HeroSection({ onShopNow }: HeroProps) {
  const [activeIndex, setActiveIndex] = useState(0);

  useEffect(() => {
    const timer = window.setInterval(() => {
      setActiveIndex((current) => (current + 1) % Math.min(products.length, 4));
    }, 6000);
    return () => window.clearInterval(timer);
  }, []);

  const activeProduct = products[activeIndex] || products[0];

  return (
    <section className="relative h-[75vh] min-h-[600px] overflow-hidden bg-[#111111]">
      <AnimatePresence mode="wait">
        <motion.div
          key={activeIndex}
          initial={{ opacity: 0, scale: 1.1 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          transition={{ duration: 1.5, ease: [0.19, 1, 0.22, 1] }}
          className="absolute inset-0"
        >
          <img
            src={activeProduct.image}
            alt={activeProduct.name}
            className="h-full w-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-[#111111]/90 via-[#111111]/40 to-transparent" />
          <div className="absolute inset-0 bg-gradient-to-t from-[#111111]/60 via-transparent to-transparent" />
        </motion.div>
      </AnimatePresence>

      <div className="relative z-10 flex h-full items-center">
        <div className="mx-auto w-full max-w-7xl px-4 sm:px-6">
          <div className="max-w-2xl">
            <motion.p
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.5 }}
              className="mb-4 text-[10px] font-bold uppercase tracking-[0.5em] text-[#BFA364]"
            >
              The Artisanal Collection
            </motion.p>
            
            <motion.h1
              key={`h1-${activeIndex}`}
              variants={containerAnimation}
              initial="hidden"
              animate="visible"
              className="font-headline text-2xl leading-none sm:text-4xl lg:text-5xl text-white whitespace-nowrap"
            >
              {activeProduct.name.split('').map((char, i) => (
                <motion.span key={i} variants={letterAnimation} className="inline-block">
                  {char === ' ' ? '\u00A0' : char}
                </motion.span>
              ))}
            </motion.h1>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 1.2 }}
              className="mt-8 flex items-center gap-8"
            >
              <button
                onClick={onShopNow}
                className="group relative overflow-hidden bg-[#BFA364] px-10 py-4 text-xs font-bold uppercase tracking-widest text-white transition-all hover:bg-[#A68A50] rounded-full"
              >
                <span className="relative z-10">Shop Now</span>
                <motion.div
                  className="absolute inset-0 bg-white/20"
                  initial={{ x: '-100%' }}
                  whileHover={{ x: '100%' }}
                  transition={{ duration: 0.5 }}
                />
              </button>
              
              <div className="flex flex-col">
                <span className="text-[10px] font-bold uppercase tracking-widest text-slate-400">Premium Quality</span>
                <span className="text-xl font-bold text-white">₹{activeProduct.price}</span>
              </div>
            </motion.div>
          </div>

          <div className="absolute bottom-12 right-4 sm:right-6 flex flex-col gap-4">
            {products.slice(0, 4).map((_, index) => (
              <button
                key={index}
                onClick={() => setActiveIndex(index)}
                className="group flex items-center gap-4"
              >
                <span className={`text-[10px] font-bold transition-all ${index === activeIndex ? 'text-[#BFA364] translate-x-0' : 'text-white/20 -translate-x-2 opacity-0'}`}>
                  0{index + 1}
                </span>
                <div className={`h-10 w-[2px] transition-all duration-500 ${index === activeIndex ? 'bg-[#BFA364] h-12' : 'bg-white/10'}`} />
              </button>
            ))}
          </div>
        </div>
      </div>
      
      {/* Decorative lines */}
      <div className="absolute top-0 left-1/4 w-[1px] h-full bg-white/5" />
      <div className="absolute top-0 left-2/4 w-[1px] h-full bg-white/5" />
      <div className="absolute top-0 left-3/4 w-[1px] h-full bg-white/5" />
    </section>
  );
}