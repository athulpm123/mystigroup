import { useState } from 'react';
import { supabase } from '../lib/supabase';
import { Helmet } from 'react-helmet-async';

export default function OrderTrackingPage() {
  const [orderId, setOrderId] = useState('');
  const [phone, setPhone] = useState('');
  const [order, setOrder] = useState<any>(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleTrack = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    setOrder(null);
    
    // We search the ID based on the first 8 characters provided by user
    const { data, error } = await supabase
      .from('orders')
      .select('*')
      .ilike('id', `${orderId.toLowerCase()}%`)
      .single();

    if (error || !data) {
      setError('Order not found. Please check your tracking number.');
    } else {
      if (data.shipping_details?.phone !== phone) {
        setError('Phone number does not match our records for this order.');
      } else {
        setOrder(data);
      }
    }
    setLoading(false);
  };

  return (
    <div className="pt-8 min-h-[70vh]">
      <Helmet>
        <title>Track Order - MystiGifts</title>
      </Helmet>
      <div className="max-w-3xl mx-auto px-4 sm:px-6 py-16">
        <div className="text-center mb-10">
          <h1 className="font-headline text-4xl text-slate-900 tracking-tight">Track Your Order</h1>
          <p className="text-gray-500 mt-2 uppercase text-[10px] font-bold tracking-[0.2em]">Enter your credentials to view status</p>
        </div>

        <div className="bg-white rounded-none shadow-2xl border border-slate-100 p-6 sm:p-10">
          <form onSubmit={handleTrack} className="space-y-6">
            <div className="grid sm:grid-cols-2 gap-6">
              <div>
                <label className="block text-[10px] font-bold uppercase tracking-widest text-slate-400 mb-2">Order ID</label>
                <input required type="text" value={orderId} onChange={e => setOrderId(e.target.value)} placeholder="e.g. 5F4E2D1C" className="w-full px-5 py-3 border border-slate-200 rounded-none focus:ring-2 focus:ring-[#BFA364] outline-none font-medium" />
              </div>
              <div>
                <label className="block text-[10px] font-bold uppercase tracking-widest text-slate-400 mb-2">Phone Number</label>
                <input required type="tel" value={phone} onChange={e => setPhone(e.target.value)} placeholder="Used during checkout" className="w-full px-5 py-3 border border-slate-200 rounded-none focus:ring-2 focus:ring-[#BFA364] outline-none font-medium" />
              </div>
            </div>
            {error && <div className="p-4 text-xs font-bold uppercase tracking-widest text-red-600 bg-red-50 border border-red-100">{error}</div>}
            <button disabled={loading} type="submit" className="w-full py-4 bg-slate-900 text-white rounded-none font-bold text-xs uppercase tracking-[0.3em] hover:bg-slate-800 transition-all shadow-xl">
              {loading ? 'Consulting Database...' : 'Track My Selection'}
            </button>
          </form>

          {order && (
            <div className="mt-12 border-t border-slate-100 pt-10">
              <div className="mb-10">
                <h3 className="font-bold text-xs uppercase tracking-[0.2em] text-slate-400 mb-6">Current Progress</h3>
                <div className="relative">
                  {/* Progress Line */}
                  <div className="absolute top-1/2 left-0 w-full h-0.5 bg-slate-100 -translate-y-1/2" />
                  
                  {/* Status Steps */}
                  <div className="relative flex justify-between">
                    {[
                      { id: 'pending', label: 'Placed' },
                      { id: 'paid', label: 'Processing' },
                      { id: 'shipped', label: 'Shipped' },
                      { id: 'delivered', label: 'Delivered' }
                    ].map((step, i) => {
                      const statuses = ['pending', 'paid', 'shipped', 'delivered'];
                      const currentIdx = statuses.indexOf(order.status);
                      const isCompleted = statuses.indexOf(step.id) <= currentIdx;
                      
                      return (
                        <div key={step.id} className="flex flex-col items-center gap-2 relative">
                          <div className={`w-4 h-4 rounded-full border-2 z-10 transition-colors duration-500 ${isCompleted ? 'bg-[#BFA364] border-[#BFA364] shadow-lg shadow-[#BFA364]/40' : 'bg-white border-slate-200'}`} />
                          <span className={`text-[10px] font-bold uppercase tracking-widest ${isCompleted ? 'text-slate-900' : 'text-slate-300'}`}>{step.label}</span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>

              <div className="bg-slate-50 p-6 border border-slate-100">
                <div className="flex justify-between text-[10px] font-bold uppercase tracking-widest mb-3">
                  <span className="text-slate-400">Order Date</span>
                  <span className="text-slate-900">{new Date(order.created_at).toLocaleDateString(undefined, { dateStyle: 'long' })}</span>
                </div>
                <div className="flex justify-between text-[10px] font-bold uppercase tracking-widest mb-3">
                  <span className="text-slate-400">Total Investment</span>
                  <span className="text-slate-900 font-headline text-sm">₹{order.total_amount}</span>
                </div>
                <div className="flex justify-between text-[10px] font-bold uppercase tracking-widest">
                  <span className="text-slate-400">Shipping To</span>
                  <span className="text-slate-900 text-right max-w-[200px]">{order.shipping_details?.address}, {order.shipping_details?.city}</span>
                </div>
              </div>
              <div className="mt-8 text-center">
                <a
                  href={`https://wa.me/919400262143?text=${encodeURIComponent(
                    `Hello MystiGifts, I need assistance with my Order #${order.id.slice(0,8)}. Can you help me?`
                  )}`}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-2 px-8 py-3 bg-green-500 text-white rounded-none font-bold text-[10px] uppercase tracking-[0.2em] hover:bg-green-600 transition-all shadow-lg"
                >
                  <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/>
                  </svg>
                  Need Help? Chat with an Artisan
                </a>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
