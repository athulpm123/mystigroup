import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { Star, MessageSquare, Send } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

interface Review {
  id: string;
  user_name: string;
  rating: number;
  comment: string;
  created_at: string;
}

export default function ReviewSection({ productId }: { productId: string }) {
  const { user } = useAuth();
  const [reviews, setReviews] = useState<Review[]>([]);
  const [newReview, setNewReview] = useState({ rating: 5, comment: '' });
  const [submitting, setSubmitting] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchReviews();
  }, [productId]);

  const fetchReviews = async () => {
    setLoading(true);
    const { data } = await supabase
      .from('reviews')
      .select('*')
      .eq('product_id', productId)
      .order('created_at', { ascending: false });
    if (data) setReviews(data);
    setLoading(false);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return alert('Please sign in to leave a review');
    
    setSubmitting(true);
    const { error } = await supabase.from('reviews').insert([
      {
        product_id: productId,
        user_id: user.id,
        user_name: user.user_metadata?.full_name || 'Anonymous',
        rating: newReview.rating,
        comment: newReview.comment
      }
    ]);

    if (!error) {
      setNewReview({ rating: 5, comment: '' });
      fetchReviews();
    }
    setSubmitting(false);
  };

  return (
    <div className="mt-12 pt-12 border-t border-slate-200">
      <div className="flex items-center gap-3 mb-8">
        <div className="p-2 bg-[#BFA364]/10 text-[#BFA364]">
          <MessageSquare className="w-6 h-6" />
        </div>
        <h2 className="text-2xl font-bold text-slate-900">Customer Reviews</h2>
      </div>

      <div className="grid md:grid-cols-3 gap-8">
        {/* Review List */}
        <div className="md:col-span-2 space-y-6">
          {loading ? (
            <p className="text-slate-500">Loading reviews...</p>
          ) : reviews.length === 0 ? (
            <div className="bg-slate-50 rounded-2xl p-8 text-center border-2 border-dashed">
              <p className="text-slate-500">No reviews yet. Be the first to share your thoughts!</p>
            </div>
          ) : (
            reviews.map((review) => (
              <div key={review.id} className="bg-white rounded-2xl p-6 border shadow-sm">
                <div className="flex items-center justify-between mb-3">
                  <div className="font-bold text-slate-900">{review.user_name}</div>
                  <div className="flex gap-0.5 text-[#BFA364]">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className={`w-4 h-4 ${i < review.rating ? 'fill-current' : 'text-slate-200'}`} />
                    ))}
                  </div>
                </div>
                <p className="text-slate-600 text-sm leading-relaxed">{review.comment}</p>
                <div className="mt-3 text-[10px] text-slate-400 uppercase font-bold tracking-wider">
                  {new Date(review.created_at).toLocaleDateString()}
                </div>
              </div>
            ))
          )}
        </div>

        {/* Add Review Form */}
        <div className="md:col-span-1">
          <div className="bg-slate-900 rounded-3xl p-6 text-white sticky top-24">
            <h3 className="text-lg font-bold mb-4">Leave a Review</h3>
            {!user ? (
              <p className="text-slate-400 text-sm">Please sign in to share your experience.</p>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-slate-400 mb-2">RATING</label>
                  <div className="flex gap-2">
                    {[1, 2, 3, 4, 5].map((num) => (
                      <button
                        key={num}
                        type="button"
                        onClick={() => setNewReview({ ...newReview, rating: num })}
                        className={`w-10 h-10 rounded-xl flex items-center justify-center transition-all ${
                          newReview.rating >= num ? 'bg-[#BFA364] text-white shadow-lg shadow-[#BFA364]/20' : 'bg-slate-800 text-slate-500'
                        }`}
                      >
                        <Star className={`w-5 h-5 ${newReview.rating >= num ? 'fill-current' : ''}`} />
                      </button>
                    ))}
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-400 mb-2">COMMENT</label>
                  <textarea
                    value={newReview.comment}
                    onChange={(e) => setNewReview({ ...newReview, comment: e.target.value })}
                    required
                    rows={4}
                    placeholder="Tell others what you think..."
                    className="w-full bg-slate-800 border-none rounded-2xl p-4 text-sm focus:ring-2 focus:ring-[#BFA364] outline-none placeholder:text-slate-600"
                  />
                </div>
                <button
                  type="submit"
                  disabled={submitting}
                  className="w-full py-3 bg-[#BFA364] text-white rounded-2xl font-bold flex items-center justify-center gap-2 hover:bg-[#A68A50] transition-all shadow-xl shadow-[#BFA364]/20"
                >
                  <Send className="w-4 h-4" /> {submitting ? 'Posting...' : 'Post Review'}
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
