import { useParams } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';

const policies = {
  'shipping-policy': {
    title: 'Shipping & Delivery Policy',
    lastUpdated: 'May 2024',
    content: `
      <p>At MystiGifts, we take pride in the artisanal quality of our personalized gifts. Each item is meticulously handcrafted to your specifications.</p>
      
      <h3>1. Handcrafting Time</h3>
      <p>Because our products are custom-made, please allow <strong>3-5 business days</strong> for production before your order is shipped.</p>
      
      <h3>2. Shipping Partners</h3>
      <p>We partner with premium logistics providers (including BlueDart, Delhivery, and DTDC) to ensure your gifts reach you safely.</p>
      
      <h3>3. Delivery Timelines</h3>
      <ul>
        <li><strong>Metro Cities:</strong> 2-4 business days after shipping.</li>
        <li><strong>Rest of India:</strong> 5-7 business days after shipping.</li>
      </ul>
      
      <h3>4. Shipping Charges</h3>
      <p>We offer complimentary shipping on all orders exceeding ₹500. For orders below ₹500, a standard shipping fee of ₹49 applies.</p>
    `
  },
  'refund-policy': {
    title: 'Refund & Cancellation Policy',
    lastUpdated: 'May 2024',
    content: `
      <p>Our commitment is to provide you with a product that tells your unique story perfectly.</p>
      
      <h3>1. Personalized Items</h3>
      <p>As per Indian E-commerce guidelines, <strong>personalized or custom-made items are not eligible for returns or exchanges</strong> unless they arrive damaged or with a manufacturing defect.</p>
      
      <h3>2. Damaged on Arrival</h3>
      <p>In the rare event that your gift arrives damaged, please record an <strong>unboxing video</strong> and contact our support via WhatsApp within 24 hours of delivery. We will replace the item at no additional cost.</p>
      
      <h3>3. Cancellations</h3>
      <p>Cancellations are only accepted within 2 hours of placing the order. Once the handcrafting process begins, we cannot cancel the order.</p>
      
      <h3>4. Refunds</h3>
      <p>If a refund is approved, it will be processed to your original payment method within 5-7 business days.</p>
    `
  },
  'terms': {
    title: 'Terms & Conditions',
    lastUpdated: 'May 2024',
    content: `
      <p>Welcome to MystiGifts. By using our website, you agree to the following terms.</p>
      
      <h3>1. Customization Accuracy</h3>
      <p>Customers are responsible for providing accurate spelling and high-quality photos for personalization. We are not liable for errors provided by the customer.</p>
      
      <h3>2. Intellectual Property</h3>
      <p>All designs, brand names, and website content are the intellectual property of MystiGifts.</p>
      
      <h3>3. Pricing & Payments</h3>
      <p>We reserve the right to change prices without notice. Payments are processed securely via our partner gateways.</p>
      
      <h3>4. Governing Law</h3>
      <p>These terms are governed by the laws of India, and any disputes will be subject to the jurisdiction of the courts in Kerala.</p>
    `
  }
};

export default function PolicyPage() {
  const { type } = useParams<{ type: string }>();
  const policy = policies[type as keyof typeof policies];

  if (!policy) return <div className="py-20 text-center uppercase tracking-widest font-bold">Policy Not Found</div>;

  return (
    <div className="pt-20 min-h-screen bg-white">
      <Helmet>
        <title>{policy.title} - MystiGifts</title>
      </Helmet>
      
      <div className="max-w-3xl mx-auto px-4 sm:px-6 py-12">
        <span className="text-[10px] font-bold uppercase tracking-[0.3em] text-[#BFA364]">Legal Information</span>
        <h1 className="font-headline text-4xl sm:text-5xl text-slate-900 mt-4 mb-2">{policy.title}</h1>
        <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mb-10">Last Updated: {policy.lastUpdated}</p>
        
        <div 
          className="prose prose-slate max-w-none 
            prose-headings:font-headline prose-headings:text-slate-900 
            prose-p:text-slate-600 prose-p:leading-relaxed
            prose-li:text-slate-600
            prose-strong:text-slate-900"
          dangerouslySetInnerHTML={{ __html: policy.content }}
        />
        
        <div className="mt-20 pt-10 border-t border-slate-100 flex flex-col items-center gap-4">
          <p className="text-sm text-slate-500 font-medium italic">Have questions about our policies?</p>
          <a 
            href="https://wa.me/919400262143" 
            target="_blank" 
            rel="noreferrer"
            className="px-8 py-3 bg-slate-900 text-white font-bold text-[10px] uppercase tracking-widest hover:bg-slate-800 transition-all"
          >
            Contact Support
          </a>
        </div>
      </div>
    </div>
  );
}
