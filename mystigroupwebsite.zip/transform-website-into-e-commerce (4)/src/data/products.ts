export interface Product {
  id: string;
  name: string;
  category: string;
  price: number;
  originalPrice: number;
  description: string;
  features: string[];
  customizable: boolean;
  customizationOptions: string[];
  badge?: string;
  image: string;
}

export interface Category {
  id: string;
  name: string;
  image: string;
}

export const categories: Category[] = [
  {
    id: 'acrylic-keychains',
    name: 'Acrylic Keychains',
    description: 'Custom acrylic keychain sets with your photo, date, name and message.',
    image: '/images/product-keychain-set.jpg',
  },
  {
    id: 'necklaces',
    name: 'Engraved Necklaces',
    description: 'Personalized photo pendants engraved with your memory.',
    image: '/images/product-engraved-necklace.jpg',
  },
  {
    id: 'car-tags',
    name: 'Car Tags',
    description: 'Custom engraved car mirror tags with image and text personalization.',
    image: '/images/product-car-tag.jpg',
  },
  {
    id: 'acrylic-lamps',
    name: '3D Acrylic Lamps',
    description: 'Glowing 3D acrylic lamps with names, date and romantic designs.',
    image: '/images/product-acrylic-lamp-valentine.jpg',
  },
];

export const products: Product[] = [
  {
    id: 'custom-acrylic-keychain-set-2',
    name: 'Custom Acrylic Keychain Set of 2',
    category: 'acrylic-keychains',
    price: 300,
    originalPrice: 600,
    description:
      'A romantic set of two custom acrylic keychains. Add your photo on one keychain and a special calendar date, names or message on the second keychain. Perfect for couples, anniversaries and Valentine gifts.',
    features: ['Set of 2', 'Photo Customization', 'Special Date Calendar', 'Free Shipping'],
    customizable: true,
    customizationOptions: ['Photo', 'Special Date'],
    badge: 'Bestseller',
    image: '/images/product-keychain-set.jpg',
  },
  {
    id: 'photo-engraved-necklace',
    name: 'Engraved Photo Necklace',
    category: 'necklaces',
    price: 400,
    originalPrice: 600,
    description:
      'A sleek engraved necklace pendant customized with your photo. A meaningful everyday keepsake and a perfect personalized gift for love, friendship, birthdays and anniversaries.',
    features: ['Photo Engraving', 'Pendant With Chain', 'Premium Finish', 'Free Shipping'],
    customizable: true,
    customizationOptions: ['Photo', 'Personal Message'],
    badge: 'Popular',
    image: '/images/product-engraved-necklace.jpg',
  },
  {
    id: 'custom-engraved-car-tag',
    name: 'Custom Engraved Car Tag',
    category: 'car-tags',
    price: 400,
    originalPrice: 600,
    description:
      'A personalized car mirror hanging tag with engraved image and custom text. Add a couple photo, names, car name, music-player design or your favorite quote for a premium car accessory gift.',
    features: ['Mirror Hanging Tag', 'Engraved Image', 'Custom Text', 'Free Shipping'],
    customizable: true,
    customizationOptions: ['Photo', 'Custom Text'],
    badge: 'New Arrival',
    image: '/images/product-car-tag.jpg',
  },
  {
    id: 'valentine-3d-acrylic-lamp',
    name: 'Valentine 3D Acrylic Lamp',
    category: 'acrylic-lamps',
    price: 999,
    originalPrice: 1499,
    description:
      'A premium glowing 3D acrylic lamp with a romantic heart and infinity design. Customize it with names, date and a short message to create a memorable Valentine or anniversary gift.',
    features: ['3D Acrylic Design', 'Warm LED Glow', 'Wooden Base', 'Name & Date Customization'],
    customizable: true,
    customizationOptions: ['Special Date', 'Names', 'Personal Message'],
    badge: 'Valentine Offer',
    image: '/images/product-acrylic-lamp-valentine.jpg',
  },
];

export const featuredProductImages = products.map((product) => ({
  id: product.id,
  name: product.name,
  image: product.image,
  price: product.price,
  originalPrice: product.originalPrice,
  category: product.category,
}));