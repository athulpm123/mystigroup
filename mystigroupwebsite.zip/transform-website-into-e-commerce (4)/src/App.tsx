import { useState, useEffect } from 'react';
import { Routes, Route, useNavigate, useLocation } from 'react-router-dom';
import Header from './components/Header';
import HomePage from './components/HomePage';
import ShopPage from './components/ShopPage';
import AboutPage from './components/AboutPage';
import ContactPage from './components/ContactPage';
import CartPage from './components/CartPage';
import ProductDetail from './components/ProductDetail';
import Footer from './components/Footer';
import ProfilePage from './components/ProfilePage';
import OrderTrackingPage from './components/OrderTrackingPage';
import AdminDashboard from './components/AdminDashboard';
import PolicyPage from './components/PolicyPage';
import { type Product } from './data/products';

export default function App() {
  const [showCart, setShowCart] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const navigate = useNavigate();
  const location = useLocation();

  // Scroll to top on page change
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [location.pathname]);

  const handleViewProduct = (product: Product) => {
    setSelectedProduct(product);
  };

  const openCart = () => {
    setShowCart(true);
    setSelectedProduct(null);
  };

  if (showCart) {
    return (
      <CartPage
        onClose={() => setShowCart(false)}
        onContinueShopping={() => {
          setShowCart(false);
          navigate('/shop');
        }}
      />
    );
  }

  return (
    <div className="min-h-screen bg-white">
      <Header onCartClick={openCart} />

      {/* Spacer for fixed header */}
      <div className="h-16" />

      {/* Page Content */}
      <Routes>
        <Route
          path="/"
          element={
            <HomePage
              onShopNow={() => navigate('/shop')}
              onSelectCategory={(catId) => {
                navigate(`/shop?category=${catId}`);
              }}
              onViewProduct={handleViewProduct}
            />
          }
        />
        <Route
          path="/shop"
          element={<ShopPage onGoToCart={openCart} initialCategory={null} />}
        />
        <Route path="/about" element={<AboutPage />} />
        <Route path="/contact" element={<ContactPage />} />
        <Route path="/profile" element={<ProfilePage />} />
        <Route path="/track-order" element={<OrderTrackingPage />} />
        <Route path="/admin" element={<AdminDashboard />} />
        <Route path="/policies/:type" element={<PolicyPage />} />
      </Routes>

      {/* Product Detail Modal */}
      {selectedProduct && (
        <ProductDetail
          product={selectedProduct}
          onClose={() => setSelectedProduct(null)}
          onGoToCart={() => {
            setSelectedProduct(null);
            openCart();
          }}
        />
      )}

      <Footer onNavigate={(page) => navigate(`/${page === 'home' ? '' : page}`)} />

      {/* WhatsApp Floating Button */}
      <a
        href="https://wa.me/918078441493?text=Hi%20MystiGifts!%20I'm%20interested%20in%20ordering%20a%20personalised%20gift."
        target="_blank"
        rel="noreferrer"
        className="fixed bottom-6 right-6 z-40 w-14 h-14 bg-green-500 rounded-full flex items-center justify-center shadow-lg shadow-green-500/30 hover:bg-green-600 hover:scale-110 transition-all"
        title="Chat on WhatsApp"
      >
        <svg className="w-7 h-7 text-white" viewBox="0 0 24 24" fill="currentColor">
          <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
        </svg>
      </a>
    </div>
  );
}
