import { Product } from '../data/products';
import { supabase } from '../lib/supabase';

export interface CartItem {
  product: Product;
  quantity: number;
  customization: {
    photo?: File | null;
    photoPreview?: string;
    names?: string;
    message?: string;
    specialDate?: string;
    additionalNotes?: string;
  };
}

export interface CustomerDetails {
  fullName: string;
  phone: string;
  email: string;
  address: string;
  city: string;
  pincode: string;
  state: string;
}

let cart: CartItem[] = [];
let listeners: (() => void)[] = [];

function notifyListeners() {
  listeners.forEach((fn) => fn());
}

export function subscribeToCart(fn: () => void) {
  listeners.push(fn);
  return () => {
    listeners = listeners.filter((l) => l !== fn);
  };
}

export function getCart(): CartItem[] {
  return cart;
}

export function addToCart(item: CartItem) {
  const existingIndex = cart.findIndex((c) => c.product.id === item.product.id);
  if (existingIndex > -1) {
    const newCart = [...cart];
    newCart[existingIndex] = {
      ...newCart[existingIndex],
      quantity: newCart[existingIndex].quantity + item.quantity,
      customization: item.customization,
    };
    cart = newCart;
  } else {
    cart = [...cart, { ...item }];
  }
  notifyListeners();
  syncCartToSupabase();
}

export function removeFromCart(productId: string) {
  cart = cart.filter((c) => c.product.id !== productId);
  notifyListeners();
  syncCartToSupabase();
}

export function updateQuantity(productId: string, quantity: number) {
  const existingIndex = cart.findIndex((c) => c.product.id === productId);
  if (existingIndex > -1) {
    const newCart = [...cart];
    newCart[existingIndex] = {
      ...newCart[existingIndex],
      quantity: Math.max(1, quantity),
    };
    cart = newCart;
    notifyListeners();
    syncCartToSupabase();
  }
}

export function clearCart() {
  cart = [];
  notifyListeners();
  syncCartToSupabase();
}

export function getCartTotal(): number {
  return cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
}

export function getCartCount(): number {
  return cart.reduce((sum, item) => sum + item.quantity, 0);
}

// Supabase Syncing Logic
async function syncCartToSupabase() {
  const { data: { session } } = await supabase.auth.getSession();
  if (!session?.user) {
    console.log('No user session, skipping sync');
    return;
  }

  console.log('Syncing cart for user:', session.user.id, 'Items:', cart.length);

  try {
    // 1. Ensure products exist
    if (cart.length > 0) {
      const { products: localProducts } = await import('../data/products');
      const productsToSeed = localProducts.map(p => ({
        id: p.id,
        name: p.name,
        description: p.description,
        price: p.price,
        original_price: p.originalPrice,
        category: p.category,
        image_url: p.image,
        is_customizable: p.customizable,
        customization_options: p.customizationOptions
      }));
      const { error: seedError } = await supabase.from('products').upsert(productsToSeed);
      if (seedError) {
        console.error('Seed Error:', seedError);
        throw new Error('Failed to sync product data: ' + seedError.message);
      }
    }

    // 2. Delete existing items
    const { error: deleteError } = await supabase.from('cart_items').delete().eq('user_id', session.user.id);
    if (deleteError) {
      console.error('Delete Error:', deleteError);
      throw new Error('Failed to clear old cart: ' + deleteError.message);
    }
    
    // 3. Insert new items
    if (cart.length > 0) {
      const itemsToInsert = cart.map(item => ({
        user_id: session.user.id,
        product_id: item.product.id,
        quantity: item.quantity,
        customization: item.customization
      }));
      
      const { error: insertError } = await supabase.from('cart_items').insert(itemsToInsert);
      if (insertError) {
        console.error('Insert Error:', insertError);
        throw new Error('Failed to save cart items: ' + insertError.message);
      }
    }
    console.log('Cart synced successfully!');
  } catch (err: any) {
    console.error('Sync Error:', err);
    alert('⚠️ Cart Sync Failed: ' + err.message);
  }
}

export async function loadCartFromSupabase() {
  const { data: { session } } = await supabase.auth.getSession();
  if (!session?.user) return;

  try {
    const { data, error } = await supabase
      .from('cart_items')
      .select('*, products(*)')
      .eq('user_id', session.user.id);

    if (error) throw error;

    if (data && data.length > 0) {
      // Map the DB structure back to our CartItem structure
      // Note: We need to make sure the product data is correctly mapped
      // Since our local 'products' data is more detailed, we'll use that as base
      const { products: localProducts } = await import('../data/products');
      
      cart = data.map(dbItem => {
        const localProduct = localProducts.find(p => p.id === dbItem.product_id);
        return {
          product: localProduct || dbItem.products,
          quantity: dbItem.quantity,
          customization: dbItem.customization
        };
      }).filter(item => item.product); // Filter out any missing products
      
      notifyListeners();
    }
  } catch (err) {
    console.error('Error loading cart from Supabase:', err);
  }
}

